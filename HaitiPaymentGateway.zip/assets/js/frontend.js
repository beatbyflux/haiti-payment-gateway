/**
 * WC Haiti Payment Methods - Frontend JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize frontend functionality
    const WC_Haiti_Frontend = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.initFileUpload();
            this.validateOnCheckout();
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // File upload events
            $(document).on('click', '.upload-button', this.triggerFileSelect);
            $(document).on('change', '#wc-haiti-receipt-file', this.handleFileSelect);
            $(document).on('click', '.remove-file', this.removeFile);
            
            // Drag and drop events
            $(document).on('dragover', '.file-drop-zone', this.handleDragOver);
            $(document).on('dragleave', '.file-drop-zone', this.handleDragLeave);
            $(document).on('drop', '.file-drop-zone', this.handleDrop);
            
            // Form submission
            $(document).on('submit', 'form.woocommerce-checkout', this.validateCheckout);
            
            // Payment method change
            $(document).on('change', 'input[name="payment_method"]', this.handlePaymentMethodChange);
            
            // Copy to clipboard functionality
            $(document).on('click', '.account-number', this.copyToClipboard);
            
            // Amount converter for NATCASH
            $(document).on('change', '.woocommerce-checkout', this.updateNatcashAmount);
        },
        
        /**
         * Initialize file upload functionality
         */
        initFileUpload: function() {
            // Prevent default drag behaviors
            $(document).on('dragenter dragover dragleave drop', '.file-drop-zone', function(e) {
                e.preventDefault();
                e.stopPropagation();
            });
        },
        
        /**
         * Trigger file select dialog
         */
        triggerFileSelect: function(e) {
            e.preventDefault();
            $('#wc-haiti-receipt-file').click();
        },
        
        /**
         * Handle file selection
         */
        handleFileSelect: function(e) {
            const files = e.target.files;
            if (files.length > 0) {
                WC_Haiti_Frontend.processFile(files[0]);
            }
        },
        
        /**
         * Handle drag over
         */
        handleDragOver: function(e) {
            e.preventDefault();
            $(this).addClass('dragover');
        },
        
        /**
         * Handle drag leave
         */
        handleDragLeave: function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
        },
        
        /**
         * Handle file drop
         */
        handleDrop: function(e) {
            e.preventDefault();
            $(this).removeClass('dragover');
            
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                WC_Haiti_Frontend.processFile(files[0]);
            }
        },
        
        /**
         * Process uploaded file
         */
        processFile: function(file) {
            // Clear previous messages
            this.clearMessages();
            
            // Validate file
            const validation = this.validateFile(file);
            if (!validation.valid) {
                this.showMessage(validation.message, 'error');
                this.clearFileInput();
                return;
            }
            
            // Show file preview
            this.showFilePreview(file);
            
            // Update file input with the selected file
            this.updateFileInput(file);
            
            this.showMessage('Fichier sélectionné avec succès', 'success');
        },
        
        /**
         * Validate file
         */
        validateFile: function(file) {
            // Check file type
            const allowedTypes = wc_haiti_frontend.allowed_types || ['image/jpeg', 'image/png', 'application/pdf'];
            if (!allowedTypes.includes(file.type)) {
                return {
                    valid: false,
                    message: 'Type de fichier non autorisé. Formats acceptés: JPG, PNG, PDF.'
                };
            }
            
            // Check file size
            const maxSize = wc_haiti_frontend.max_file_size || (5 * 1024 * 1024); // 5MB
            if (file.size > maxSize) {
                return {
                    valid: false,
                    message: 'Fichier trop volumineux. Taille maximale autorisée: ' + this.formatFileSize(maxSize) + '.'
                };
            }
            
            // Additional validation for images
            if (file.type.startsWith('image/')) {
                return this.validateImage(file);
            }
            
            return { valid: true };
        },
        
        /**
         * Validate image file
         */
        validateImage: function(file) {
            return new Promise((resolve) => {
                const img = new Image();
                const url = URL.createObjectURL(file);
                
                img.onload = function() {
                    URL.revokeObjectURL(url);
                    
                    // Check minimum dimensions
                    if (this.width < 100 || this.height < 100) {
                        resolve({
                            valid: false,
                            message: 'Image trop petite. Dimensions minimales: 100x100 pixels.'
                        });
                    } else {
                        resolve({ valid: true });
                    }
                };
                
                img.onerror = function() {
                    URL.revokeObjectURL(url);
                    resolve({
                        valid: false,
                        message: 'Fichier image corrompu ou non valide.'
                    });
                };
                
                img.src = url;
            });
        },
        
        /**
         * Show file preview
         */
        showFilePreview: function(file) {
            const $preview = $('#wc-haiti-file-preview');
            const $dropZone = $('#wc-haiti-drop-zone');
            
            // Update file info
            $preview.find('.file-name').text(file.name);
            $preview.find('.file-size').text('(' + this.formatFileSize(file.size) + ')');
            
            // Show preview, hide drop zone
            $dropZone.hide();
            $preview.show();
        },
        
        /**
         * Remove file
         */
        removeFile: function(e) {
            e.preventDefault();
            WC_Haiti_Frontend.clearFileInput();
            WC_Haiti_Frontend.clearMessages();
        },
        
        /**
         * Clear file input and preview
         */
        clearFileInput: function() {
            const $fileInput = $('#wc-haiti-receipt-file');
            const $preview = $('#wc-haiti-file-preview');
            const $dropZone = $('#wc-haiti-drop-zone');
            
            $fileInput.val('');
            $preview.hide();
            $dropZone.show();
        },
        
        /**
         * Update file input with selected file
         */
        updateFileInput: function(file) {
            const $fileInput = $('#wc-haiti-receipt-file')[0];
            
            // Create new FileList with the selected file
            const dt = new DataTransfer();
            dt.items.add(file);
            $fileInput.files = dt.files;
        },
        
        /**
         * Format file size
         */
        formatFileSize: function(bytes) {
            if (bytes === 0) return '0 Bytes';
            
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        },
        
        /**
         * Show message
         */
        showMessage: function(message, type) {
            const $container = $('#wc-haiti-upload-messages');
            const className = type === 'error' ? 'error-message' : 'success-message';
            
            $container.html('<div class="' + className + '">' + message + '</div>');
            
            // Auto-hide success messages
            if (type === 'success') {
                setTimeout(function() {
                    $container.fadeOut(function() {
                        $container.empty().show();
                    });
                }, 3000);
            }
        },
        
        /**
         * Clear messages
         */
        clearMessages: function() {
            $('#wc-haiti-upload-messages').empty();
        },
        
        /**
         * Validate checkout form
         */
        validateCheckout: function(e) {
            const selectedPaymentMethod = $('input[name="payment_method"]:checked').val();
            
            // Check if it's a Haiti payment method
            if (selectedPaymentMethod && selectedPaymentMethod.startsWith('haiti_')) {
                const $fileInput = $('#wc-haiti-receipt-file');
                
                if (!$fileInput.length || !$fileInput.val()) {
                    e.preventDefault();
                    WC_Haiti_Frontend.showMessage('Veuillez télécharger votre reçu de paiement avant de continuer.', 'error');
                    
                    // Scroll to upload section
                    $('html, body').animate({
                        scrollTop: $('.wc-haiti-receipt-upload').offset().top - 50
                    }, 500);
                    
                    return false;
                }
            }
            
            return true;
        },
        
        /**
         * Validate form on checkout page load
         */
        validateOnCheckout: function() {
            // Add real-time validation
            $(document).on('change', 'input[name="payment_method"]', function() {
                WC_Haiti_Frontend.clearMessages();
            });
        },
        
        /**
         * Handle payment method change
         */
        handlePaymentMethodChange: function() {
            const selectedMethod = $(this).val();
            
            // Show/hide file upload based on payment method
            if (selectedMethod && selectedMethod.startsWith('haiti_')) {
                $('.wc-haiti-receipt-upload').slideDown();
            } else {
                $('.wc-haiti-receipt-upload').slideUp();
                WC_Haiti_Frontend.clearFileInput();
                WC_Haiti_Frontend.clearMessages();
            }
        },
        
        /**
         * Copy account number to clipboard
         */
        copyToClipboard: function(e) {
            e.preventDefault();
            
            const text = $(this).text();
            
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function() {
                    WC_Haiti_Frontend.showMessage('Numéro de compte copié dans le presse-papier', 'success');
                }).catch(function() {
                    WC_Haiti_Frontend.fallbackCopyToClipboard(text);
                });
            } else {
                WC_Haiti_Frontend.fallbackCopyToClipboard(text);
            }
        },
        
        /**
         * Fallback copy to clipboard method
         */
        fallbackCopyToClipboard: function(text) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                WC_Haiti_Frontend.showMessage('Numéro de compte copié dans le presse-papier', 'success');
            } catch (err) {
                WC_Haiti_Frontend.showMessage('Impossible de copier automatiquement. Veuillez sélectionner le texte manuellement.', 'error');
            }
            
            document.body.removeChild(textArea);
        },
        
        /**
         * Update NATCASH amount when cart total changes
         */
        updateNatcashAmount: function() {
            // This would be triggered by WooCommerce checkout updates
            const $natcashFields = $('.natcash-payment');
            
            if ($natcashFields.length) {
                // Get updated cart total (this would come from WooCommerce)
                const cartTotal = parseFloat($('#order_review .order-total .amount').text().replace(/[^0-9.]/g, ''));
                
                if (!isNaN(cartTotal)) {
                    const htgRate = 134; // This should come from settings
                    const htgAmount = (cartTotal * htgRate).toFixed(2);
                    
                    $natcashFields.find('.amount-htg').text(parseFloat(htgAmount).toLocaleString('fr-FR', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }) + ' HTG');
                }
            }
        },
        
        /**
         * Show loading state
         */
        showLoading: function($element) {
            $element.addClass('loading').prop('disabled', true);
        },
        
        /**
         * Hide loading state
         */
        hideLoading: function($element) {
            $element.removeClass('loading').prop('disabled', false);
        },
        
        /**
         * Animate element
         */
        animateElement: function($element, animation) {
            $element.addClass('animate-' + animation);
            setTimeout(function() {
                $element.removeClass('animate-' + animation);
            }, 600);
        }
    };
    
    // Initialize when document is ready
    WC_Haiti_Frontend.init();
    
    // Make it globally accessible
    window.WC_Haiti_Frontend = WC_Haiti_Frontend;
    
    // Handle WooCommerce checkout updates
    $(document.body).on('updated_checkout', function() {
        WC_Haiti_Frontend.updateNatcashAmount();
    });
});

/**
 * File upload progress handler
 */
function handleFileUploadProgress(event) {
    if (event.lengthComputable) {
        const percentComplete = (event.loaded / event.total) * 100;
        const $progressBar = jQuery('#wc-haiti-upload-progress');
        const $progressFill = $progressBar.find('.progress-fill');
        const $progressText = $progressBar.find('.progress-text');
        
        $progressBar.show();
        $progressFill.css('width', percentComplete + '%');
        $progressText.text(Math.round(percentComplete) + '%');
        
        if (percentComplete >= 100) {
            setTimeout(function() {
                $progressBar.fadeOut();
            }, 1000);
        }
    }
}

/**
 * Mobile device detection and optimization
 */
jQuery(document).ready(function($) {
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        // Mobile optimizations
        $('.file-drop-zone').addClass('mobile-optimized');
        
        // Adjust file input for mobile
        $('#wc-haiti-receipt-file').attr('capture', 'environment');
        
        // Simplify drag and drop on mobile
        $('.file-drop-zone').off('dragover dragleave drop');
    }
});

/**
 * Accessibility enhancements
 */
jQuery(document).ready(function($) {
    // Add ARIA labels
    $('#wc-haiti-receipt-file').attr('aria-describedby', 'upload-instructions');
    $('.upload-requirements').attr('id', 'upload-instructions');
    
    // Keyboard navigation for custom elements
    $('.upload-button').on('keydown', function(e) {
        if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
            e.preventDefault();
            $(this).click();
        }
    });
    
    $('.remove-file').on('keydown', function(e) {
        if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
            e.preventDefault();
            $(this).click();
        }
    });
});

/**
 * Error handling and retry mechanism
 */
function retryFileUpload(file, attempts = 3) {
    if (attempts <= 0) {
        WC_Haiti_Frontend.showMessage('Échec du téléchargement après plusieurs tentatives. Veuillez réessayer.', 'error');
        return;
    }
    
    // Implement retry logic here
    setTimeout(function() {
        WC_Haiti_Frontend.processFile(file);
    }, 1000);
}

/**
 * Performance optimization
 */
jQuery(document).ready(function($) {
    // Debounce file validation
    let validationTimeout;
    $(document).on('change', '#wc-haiti-receipt-file', function() {
        clearTimeout(validationTimeout);
        validationTimeout = setTimeout(function() {
            // Perform validation
        }, 300);
    });
    
    // Lazy load payment method details
    $(document).on('focus', '.wc-haiti-payment-fields', function() {
        if (!$(this).hasClass('details-loaded')) {
            $(this).addClass('details-loaded');
            // Load additional details if needed
        }
    });
});
