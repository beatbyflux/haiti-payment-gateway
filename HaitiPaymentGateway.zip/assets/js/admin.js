/**
 * WC Haiti Payment Methods - Admin JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize admin functionality
    const WC_Haiti_Admin = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.initModals();
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Receipt actions
            $(document).on('click', '.wc-haiti-view-receipt', this.viewReceipt);
            $(document).on('click', '.wc-haiti-approve-receipt', this.showApprovalModal);
            $(document).on('click', '.wc-haiti-reject-receipt', this.showRejectionModal);
            
            // Modal actions
            $(document).on('click', '.wc-haiti-modal-close', this.closeModal);
            $(document).on('click', '#wc-haiti-confirm-action', this.confirmAction);
            
            // Click outside modal to close
            $(document).on('click', '.wc-haiti-modal', function(e) {
                if (e.target === this) {
                    WC_Haiti_Admin.closeModal();
                }
            });
            
            // Escape key to close modal
            $(document).on('keydown', function(e) {
                if (e.keyCode === 27) { // ESC key
                    WC_Haiti_Admin.closeModal();
                }
            });
            
            // Export CSV
            $(document).on('click', '[href*="export_csv"]', this.handleExport);
            
            // Cleanup files
            $(document).on('click', '#wc-haiti-cleanup-files', this.cleanupFiles);
            
            // Auto-refresh pending receipts
            if (window.location.href.indexOf('tab=pending') !== -1) {
                setInterval(this.refreshPendingCount, 30000); // Every 30 seconds
            }
        },
        
        /**
         * Initialize modals
         */
        initModals: function() {
            // Create modal containers if they don't exist
            if ($('#wc-haiti-receipt-modal').length === 0) {
                $('body').append(this.getReceiptModalHTML());
            }
            if ($('#wc-haiti-approval-modal').length === 0) {
                $('body').append(this.getApprovalModalHTML());
            }
        },
        
        /**
         * View receipt details
         */
        viewReceipt: function(e) {
            e.preventDefault();
            
            const receiptId = $(this).data('receipt-id');
            const $button = $(this);
            
            $button.prop('disabled', true).text('Chargement...');
            
            $.ajax({
                url: wc_haiti_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'wc_haiti_get_receipt_details',
                    receipt_id: receiptId,
                    nonce: wc_haiti_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        WC_Haiti_Admin.showReceiptModal(response.data);
                    } else {
                        WC_Haiti_Admin.showNotice('Erreur: ' + (response.data || 'Impossible de charger le reçu'), 'error');
                    }
                },
                error: function() {
                    WC_Haiti_Admin.showNotice('Erreur de connexion', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Voir');
                }
            });
        },
        
        /**
         * Show receipt modal
         */
        showReceiptModal: function(data) {
            const $modal = $('#wc-haiti-receipt-modal');
            const $details = $('#wc-haiti-receipt-details');
            const $preview = $('#wc-haiti-receipt-preview');
            
            // Build receipt details HTML
            let detailsHTML = '<div class="wc-haiti-receipt-details">';
            detailsHTML += '<div class="detail-row"><span class="label">ID du reçu:</span><span class="value">' + data.receipt.id + '</span></div>';
            detailsHTML += '<div class="detail-row"><span class="label">Commande:</span><span class="value">#' + data.receipt.order_id + '</span></div>';
            detailsHTML += '<div class="detail-row"><span class="label">Méthode de paiement:</span><span class="value">' + data.receipt.payment_method + '</span></div>';
            detailsHTML += '<div class="detail-row"><span class="label">Statut:</span><span class="value">' + this.getStatusLabel(data.receipt.status) + '</span></div>';
            detailsHTML += '<div class="detail-row"><span class="label">Date:</span><span class="value">' + data.receipt.created_at + '</span></div>';
            
            if (data.order) {
                detailsHTML += '<div class="detail-row"><span class="label">Client:</span><span class="value">' + data.order.billing.first_name + ' ' + data.order.billing.last_name + '</span></div>';
                detailsHTML += '<div class="detail-row"><span class="label">Email:</span><span class="value">' + data.order.billing.email + '</span></div>';
                detailsHTML += '<div class="detail-row"><span class="label">Total:</span><span class="value">' + data.order.total + ' ' + data.order.currency + '</span></div>';
            }
            
            if (data.receipt.admin_notes) {
                detailsHTML += '<div class="detail-row"><span class="label">Notes admin:</span><span class="value">' + data.receipt.admin_notes + '</span></div>';
            }
            
            detailsHTML += '</div>';
            
            $details.html(detailsHTML);
            $preview.attr('src', data.receipt_url);
            
            this.showModal($modal);
        },
        
        /**
         * Show approval modal
         */
        showApprovalModal: function(e) {
            e.preventDefault();
            
            const receiptId = $(this).data('receipt-id');
            const $modal = $('#wc-haiti-approval-modal');
            
            $('#wc-haiti-approval-title').text('Approuver le reçu');
            $('#wc-haiti-receipt-id').val(receiptId);
            $('#wc-haiti-action-type').val('approve');
            $('#wc-haiti-admin-notes').val('').attr('placeholder', 'Notes d\'approbation (optionnel)');
            $('#wc-haiti-confirm-action').text('Approuver').removeClass('button-secondary').addClass('button-primary');
            
            WC_Haiti_Admin.showModal($modal);
        },
        
        /**
         * Show rejection modal
         */
        showRejectionModal: function(e) {
            e.preventDefault();
            
            const receiptId = $(this).data('receipt-id');
            const $modal = $('#wc-haiti-approval-modal');
            
            $('#wc-haiti-approval-title').text('Rejeter le reçu');
            $('#wc-haiti-receipt-id').val(receiptId);
            $('#wc-haiti-action-type').val('reject');
            $('#wc-haiti-admin-notes').val('').attr('placeholder', 'Raison du rejet (requis)');
            $('#wc-haiti-confirm-action').text('Rejeter').removeClass('button-primary').addClass('button-secondary');
            
            WC_Haiti_Admin.showModal($modal);
        },
        
        /**
         * Confirm action (approve/reject)
         */
        confirmAction: function(e) {
            e.preventDefault();
            
            const receiptId = $('#wc-haiti-receipt-id').val();
            const actionType = $('#wc-haiti-action-type').val();
            const adminNotes = $('#wc-haiti-admin-notes').val().trim();
            const $button = $(this);
            
            // Validate required fields for rejection
            if (actionType === 'reject' && !adminNotes) {
                WC_Haiti_Admin.showNotice('Veuillez indiquer la raison du rejet', 'error');
                $('#wc-haiti-admin-notes').focus();
                return;
            }
            
            $button.prop('disabled', true).text('Traitement...');
            
            const ajaxAction = actionType === 'approve' ? 'wc_haiti_approve_receipt' : 'wc_haiti_reject_receipt';
            
            $.ajax({
                url: wc_haiti_admin.ajax_url,
                type: 'POST',
                data: {
                    action: ajaxAction,
                    receipt_id: receiptId,
                    admin_notes: adminNotes,
                    nonce: wc_haiti_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        WC_Haiti_Admin.showNotice(response.data, 'success');
                        WC_Haiti_Admin.closeModal();
                        
                        // Refresh the page to show updated status
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        WC_Haiti_Admin.showNotice('Erreur: ' + (response.data || 'Action échouée'), 'error');
                    }
                },
                error: function() {
                    WC_Haiti_Admin.showNotice('Erreur de connexion', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text(actionType === 'approve' ? 'Approuver' : 'Rejeter');
                }
            });
        },
        
        /**
         * Show modal
         */
        showModal: function($modal) {
            $modal.addClass('show').show();
            $('body').addClass('modal-open');
            
            // Focus first focusable element
            setTimeout(function() {
                $modal.find('button, input, textarea').first().focus();
            }, 100);
        },
        
        /**
         * Close modal
         */
        closeModal: function() {
            $('.wc-haiti-modal').removeClass('show').hide();
            $('body').removeClass('modal-open');
        },
        
        /**
         * Show admin notice
         */
        showNotice: function(message, type) {
            const noticeClass = type === 'error' ? 'notice-error' : 'notice-success';
            const $notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
            
            $('.wrap h1').after($notice);
            
            // Auto-dismiss after 5 seconds
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
            
            // Scroll to notice
            $('html, body').animate({
                scrollTop: $notice.offset().top - 50
            }, 300);
        },
        
        /**
         * Get status label
         */
        getStatusLabel: function(status) {
            const labels = {
                'pending': 'En attente',
                'verified': 'Vérifié',
                'rejected': 'Rejeté'
            };
            return labels[status] || status;
        },
        
        /**
         * Handle CSV export
         */
        handleExport: function(e) {
            const $link = $(this);
            $link.text('Export en cours...');
            
            // Reset text after delay
            setTimeout(function() {
                $link.text('Exporter CSV');
            }, 3000);
        },
        
        /**
         * Cleanup orphaned files
         */
        cleanupFiles: function(e) {
            e.preventDefault();
            
            if (!confirm('Êtes-vous sûr de vouloir nettoyer les fichiers orphelins ? Cette action est irréversible.')) {
                return;
            }
            
            const $button = $(this);
            $button.prop('disabled', true).text('Nettoyage en cours...');
            
            $.ajax({
                url: wc_haiti_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'wc_haiti_cleanup_files',
                    nonce: wc_haiti_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        WC_Haiti_Admin.showNotice('Nettoyage terminé avec succès', 'success');
                    } else {
                        WC_Haiti_Admin.showNotice('Erreur lors du nettoyage: ' + (response.data || 'Erreur inconnue'), 'error');
                    }
                },
                error: function() {
                    WC_Haiti_Admin.showNotice('Erreur de connexion lors du nettoyage', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Nettoyer les fichiers orphelins');
                }
            });
        },
        
        /**
         * Refresh pending receipts count
         */
        refreshPendingCount: function() {
            $.ajax({
                url: wc_haiti_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'wc_haiti_get_pending_count',
                    nonce: wc_haiti_admin.nonce
                },
                success: function(response) {
                    if (response.success && response.data.count !== undefined) {
                        // Update tab count
                        const $pendingTab = $('.nav-tab').filter(function() {
                            return $(this).attr('href').indexOf('tab=pending') !== -1;
                        });
                        
                        if ($pendingTab.length) {
                            const newText = $pendingTab.text().replace(/\(\d+\)/, '(' + response.data.count + ')');
                            $pendingTab.text(newText);
                        }
                        
                        // Show notification if new receipts
                        if (response.data.has_new) {
                            WC_Haiti_Admin.showNotice('Nouveaux reçus en attente de validation', 'info');
                        }
                    }
                }
            });
        },
        
        /**
         * Get receipt modal HTML
         */
        getReceiptModalHTML: function() {
            return `
                <div id="wc-haiti-receipt-modal" class="wc-haiti-modal" style="display: none;">
                    <div class="wc-haiti-modal-content">
                        <div class="wc-haiti-modal-header">
                            <h3>Détails du reçu</h3>
                            <button type="button" class="wc-haiti-modal-close">&times;</button>
                        </div>
                        <div class="wc-haiti-modal-body">
                            <div id="wc-haiti-receipt-details"></div>
                            <iframe id="wc-haiti-receipt-preview" style="width: 100%; height: 400px; border: 1px solid #ddd; margin-top: 15px;"></iframe>
                        </div>
                        <div class="wc-haiti-modal-footer">
                            <button type="button" class="button wc-haiti-modal-close">Fermer</button>
                        </div>
                    </div>
                </div>
            `;
        },
        
        /**
         * Get approval modal HTML
         */
        getApprovalModalHTML: function() {
            return `
                <div id="wc-haiti-approval-modal" class="wc-haiti-modal" style="display: none;">
                    <div class="wc-haiti-modal-content">
                        <div class="wc-haiti-modal-header">
                            <h3 id="wc-haiti-approval-title">Approuver le reçu</h3>
                            <button type="button" class="wc-haiti-modal-close">&times;</button>
                        </div>
                        <div class="wc-haiti-modal-body">
                            <form id="wc-haiti-approval-form">
                                <p>
                                    <label for="wc-haiti-admin-notes">Notes administratives:</label>
                                    <textarea id="wc-haiti-admin-notes" name="admin_notes" rows="4" style="width: 100%; margin-top: 5px;" placeholder="Notes d'approbation (optionnel)"></textarea>
                                </p>
                                <input type="hidden" id="wc-haiti-receipt-id" name="receipt_id" value="">
                                <input type="hidden" id="wc-haiti-action-type" name="action_type" value="">
                            </form>
                        </div>
                        <div class="wc-haiti-modal-footer">
                            <button type="button" class="button button-primary" id="wc-haiti-confirm-action">Confirmer</button>
                            <button type="button" class="button wc-haiti-modal-close">Annuler</button>
                        </div>
                    </div>
                </div>
            `;
        }
    };
    
    // Initialize when document is ready
    WC_Haiti_Admin.init();
    
    // Make it globally accessible
    window.WC_Haiti_Admin = WC_Haiti_Admin;
});

/**
 * Keyboard navigation for modals
 */
jQuery(document).on('keydown', '.wc-haiti-modal', function(e) {
    if (e.keyCode === 9) { // Tab key
        const $modal = jQuery(this);
        const $focusableElements = $modal.find('button, input, textarea, select, a[href]').filter(':visible');
        const $firstElement = $focusableElements.first();
        const $lastElement = $focusableElements.last();
        
        if (e.shiftKey) {
            // Shift + Tab
            if (document.activeElement === $firstElement[0]) {
                e.preventDefault();
                $lastElement.focus();
            }
        } else {
            // Tab
            if (document.activeElement === $lastElement[0]) {
                e.preventDefault();
                $firstElement.focus();
            }
        }
    }
});

/**
 * Auto-save form data in localStorage
 */
jQuery(document).on('input', '#wc-haiti-admin-notes', function() {
    const receiptId = jQuery('#wc-haiti-receipt-id').val();
    const notes = jQuery(this).val();
    
    if (receiptId) {
        localStorage.setItem('wc_haiti_notes_' + receiptId, notes);
    }
});

/**
 * Restore form data from localStorage
 */
jQuery(document).on('focus', '#wc-haiti-admin-notes', function() {
    const receiptId = jQuery('#wc-haiti-receipt-id').val();
    
    if (receiptId) {
        const savedNotes = localStorage.getItem('wc_haiti_notes_' + receiptId);
        if (savedNotes && !jQuery(this).val()) {
            jQuery(this).val(savedNotes);
        }
    }
});

/**
 * Clear saved data when action is completed
 */
jQuery(document).on('click', '#wc-haiti-confirm-action', function() {
    const receiptId = jQuery('#wc-haiti-receipt-id').val();
    if (receiptId) {
        localStorage.removeItem('wc_haiti_notes_' + receiptId);
    }
});
