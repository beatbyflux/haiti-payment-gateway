# WooCommerce Haiti Payment Methods

Un plugin WooCommerce complet pour les méthodes de paiement haïtiennes avec système de téléchargement de reçus et validation administrative.

## Description

Ce plugin permet aux sites e-commerce utilisant WooCommerce d'accepter des paiements via les méthodes populaires en Haïti, incluant les portefeuilles mobiles, virements bancaires et services de transfert d'argent. Les clients peuvent télécharger leurs reçus de paiement pour validation manuelle par l'administrateur.

## Méthodes de Paiement Supportées

### 1. NATCASH (Portefeuille Mobile)
- Conversion automatique USD → HTG (taux configurable)
- Affichage du montant en gourdes haïtiennes
- Instructions de paiement détaillées

### 2. Banques
- **SOGEBANK** - Virement bancaire avec informations complètes
- **UNIBANK** - Virement bancaire avec informations complètes

### 3. Services de Transfert d'Argent
- **Western Union**
- **MoneyGram** 
- **Unitransfert**
- **CAM Transfert**

Chaque service inclut toutes les informations du bénéficiaire nécessaires pour effectuer le transfert.

## Fonctionnalités Principales

### Gestion des Reçus
- **Upload sécurisé** : JPG, PNG, PDF (max 5MB)
- **Validation des fichiers** : Vérification du type MIME et de la taille
- **Stockage sécurisé** : Fichiers stockés hors du répertoire web
- **Statuts de validation** : En attente, Vérifié, Rejeté

### Interface Administrateur
- **Page de gestion** : Liste et validation des reçus
- **Aperçu des reçus** : Visualisation directe dans l'admin
- **Notes administratives** : Commentaires pour approbation/rejet
- **Export CSV** : Export des données de paiement
- **Statistiques** : Tableau de bord avec métriques

### Statuts de Commande Personnalisés
- "En attente de paiement"
- "Paiement en cours de vérification" 
- "Paiement vérifié"
- "Paiement rejeté"

### Système de Notifications
- **Emails automatiques** avec templates HTML
- **Instructions de paiement** envoyées au client
- **Notifications admin** pour nouveaux reçus
- **Confirmations de validation** pour les clients

## Prérequis

- **WordPress** : 5.0 ou supérieur
- **WooCommerce** : 4.0 ou supérieur  
- **PHP** : 7.4 ou supérieur
- **Extensions PHP** : fileinfo, gd (pour validation d'images)

## Installation

### Installation Manuelle

1. **Télécharger le plugin**
   ```bash
   git clone https://github.com/votre-repo/wc-haiti-payment-methods.git
   