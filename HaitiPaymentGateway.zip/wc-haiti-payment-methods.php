<?php
/**
 * Plugin Name: WooCommerce Haiti Payment Methods
 * Plugin URI: https://wordpress.org/plugins/wc-haiti-payment-methods
 * Description: Plugin WooCommerce pour les méthodes de paiement haïtiennes avec upload de reçus et validation administrative.
 * Version: 1.0.0
 * Author: WC Haiti Team
 * Author URI: #
 * Text Domain: wc-haiti-payment-methods
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * WC requires at least: 4.0
 * WC tested up to: 8.4
 * Requires Plugins: woocommerce
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Network: false
 */

// Declare HPOS compatibility
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('orders_cache', __FILE__, true);
    }
});

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WC_HAITI_PLUGIN_FILE', __FILE__);
define('WC_HAITI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WC_HAITI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('WC_HAITI_PLUGIN_VERSION', '1.0.0');
define('WC_HAITI_UPLOADS_DIR', wp_upload_dir()['basedir'] . '/wc-haiti-receipts/');

/**
 * Main plugin class
 */
class WC_Haiti_Payment_Methods {
    
    /**
     * Plugin instance
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }
        
        // Load text domain
        load_plugin_textdomain('wc-haiti-payment-methods', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        
        // Include required files
        $this->includes();
        
        // Initialize classes
        $this->init_classes();
        
        // Add payment gateways - use proper WooCommerce hooks
        add_filter('woocommerce_payment_gateways', array($this, 'add_payment_gateways'), 10, 1);
        
        // Ensure gateways are properly enabled by default
        add_action('init', array($this, 'maybe_enable_gateways'));
        
        // Debug payment gateways if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            add_action('wp_footer', array($this, 'debug_payment_gateways'));
        }
        
        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', array($this, 'add_admin_menu'));
            add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        }
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
    }
    
    /**
     * Include required files
     */
    private function includes() {
        // Core classes
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-payment-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-receipt-handler.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-admin.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-emails.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-order-statuses.php';
        
        // Payment gateway classes
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-natcash-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-sogebank-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-unibank-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-unitransfert-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-western-union-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-cam-transfert-gateway.php';
        include_once WC_HAITI_PLUGIN_PATH . 'includes/class-wc-haiti-moneygram-gateway.php';
    }
    
    /**
     * Initialize classes
     */
    private function init_classes() {
        WC_Haiti_Receipt_Handler::get_instance();
        WC_Haiti_Admin::get_instance();
        WC_Haiti_Emails::get_instance();
        WC_Haiti_Order_Statuses::get_instance();
    }
    
    /**
     * Add payment gateways
     */
    public function add_payment_gateways($gateways) {
        // Only add gateways if their classes exist
        if (class_exists('WC_Haiti_Natcash_Gateway')) {
            $gateways[] = 'WC_Haiti_Natcash_Gateway';
        }
        if (class_exists('WC_Haiti_Sogebank_Gateway')) {
            $gateways[] = 'WC_Haiti_Sogebank_Gateway';
        }
        if (class_exists('WC_Haiti_Unibank_Gateway')) {
            $gateways[] = 'WC_Haiti_Unibank_Gateway';
        }
        if (class_exists('WC_Haiti_Unitransfert_Gateway')) {
            $gateways[] = 'WC_Haiti_Unitransfert_Gateway';
        }
        if (class_exists('WC_Haiti_Western_Union_Gateway')) {
            $gateways[] = 'WC_Haiti_Western_Union_Gateway';
        }
        if (class_exists('WC_Haiti_Cam_Transfert_Gateway')) {
            $gateways[] = 'WC_Haiti_Cam_Transfert_Gateway';
        }
        if (class_exists('WC_Haiti_Moneygram_Gateway')) {
            $gateways[] = 'WC_Haiti_Moneygram_Gateway';
        }
        
        return $gateways;
    }
    
    /**
     * Maybe enable gateways on first install
     */
    public function maybe_enable_gateways() {
        // Check if this is the first run
        if (!get_option('wc_haiti_gateways_enabled')) {
            // Enable at least one gateway by default (NATCASH)
            $settings = get_option('woocommerce_haiti_natcash_settings', array());
            if (empty($settings)) {
                $default_settings = array(
                    'enabled' => 'yes',
                    'title' => 'NATCASH',
                    'description' => 'Paiement via portefeuille mobile NATCASH avec conversion automatique USD→HTG'
                );
                update_option('woocommerce_haiti_natcash_settings', $default_settings);
            }
            
            update_option('wc_haiti_gateways_enabled', true);
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            __('Paiements Haïti', 'wc-haiti-payment-methods'),
            __('Paiements Haïti', 'wc-haiti-payment-methods'),
            'manage_woocommerce',
            'wc-haiti-payments',
            array($this, 'admin_page')
        );
    }
    
    /**
     * Admin page callback
     */
    public function admin_page() {
        include WC_HAITI_PLUGIN_PATH . 'admin/admin-receipts.php';
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_scripts($hook) {
        if (strpos($hook, 'wc-haiti') !== false) {
            wp_enqueue_style('wc-haiti-admin', WC_HAITI_PLUGIN_URL . 'assets/css/admin.css', array(), WC_HAITI_PLUGIN_VERSION);
            wp_enqueue_script('wc-haiti-admin', WC_HAITI_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WC_HAITI_PLUGIN_VERSION, true);
            
            wp_localize_script('wc-haiti-admin', 'wc_haiti_admin', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wc_haiti_admin_nonce')
            ));
        }
    }
    
    /**
     * Enqueue frontend scripts
     */
    public function frontend_scripts() {
        if (is_checkout() || is_account_page()) {
            wp_enqueue_style('wc-haiti-frontend', WC_HAITI_PLUGIN_URL . 'assets/css/frontend.css', array(), WC_HAITI_PLUGIN_VERSION);
            wp_enqueue_script('wc-haiti-frontend', WC_HAITI_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), WC_HAITI_PLUGIN_VERSION, true);
            
            wp_localize_script('wc-haiti-frontend', 'wc_haiti_frontend', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wc_haiti_frontend_nonce'),
                'max_file_size' => 5 * 1024 * 1024, // 5MB
                'allowed_types' => array('image/jpeg', 'image/png', 'application/pdf')
            ));
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create upload directory
        if (!file_exists(WC_HAITI_UPLOADS_DIR)) {
            wp_mkdir_p(WC_HAITI_UPLOADS_DIR);
            
            // Create .htaccess to protect uploads
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "deny from all\n";
            file_put_contents(WC_HAITI_UPLOADS_DIR . '.htaccess', $htaccess_content);
        }
        
        // Create database table
        $this->create_receipts_table();
        
        // Add rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Create receipts table
     */
    private function create_receipts_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) NOT NULL,
            payment_method varchar(50) NOT NULL,
            receipt_file varchar(255) NOT NULL,
            status varchar(20) DEFAULT 'pending',
            admin_notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY order_id (order_id),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Debug payment gateways
     */
    public function debug_payment_gateways() {
        if (!is_checkout()) return;
        
        $available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
        $haiti_gateways = array();
        
        foreach ($available_gateways as $gateway_id => $gateway) {
            if (strpos($gateway_id, 'haiti_') === 0) {
                $haiti_gateways[$gateway_id] = $gateway->title;
            }
        }
        
        if (!empty($haiti_gateways)) {
            echo '<!-- Haiti Payment Gateways Debug: ' . json_encode($haiti_gateways) . ' -->';
        } else {
            echo '<!-- Haiti Payment Gateways Debug: No Haiti gateways found -->';
        }
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        echo '<div class="error"><p><strong>' . 
             __('WooCommerce Haiti Payment Methods', 'wc-haiti-payment-methods') . 
             '</strong> ' . 
             __('nécessite WooCommerce pour fonctionner.', 'wc-haiti-payment-methods') . 
             '</p></div>';
    }
}

// Initialize plugin
WC_Haiti_Payment_Methods::get_instance();
