<?php
/**
 * WooCommerce Haiti Payment Methods Uninstall
 * 
 * This file is called when the plugin is uninstalled via WordPress admin.
 * It handles the cleanup of plugin data including database tables, 
 * uploaded files, and WordPress options.
 */

// Prevent direct access
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Plugin Uninstall Handler
 */
class WC_Haiti_Uninstaller {
    
    /**
     * Run uninstall process
     */
    public static function uninstall() {
        // Verify user has permission to uninstall plugins
        if (!current_user_can('delete_plugins')) {
            return;
        }
        
        // Verify this is actually being uninstalled
        if (!defined('WP_UNINSTALL_PLUGIN')) {
            return;
        }
        
        // Check if we should preserve data
        $preserve_data = get_option('wc_haiti_preserve_data_on_uninstall', false);
        
        if (!$preserve_data) {
            self::delete_database_tables();
            self::delete_uploaded_files();
            self::delete_plugin_options();
            self::cleanup_user_meta();
            self::cleanup_post_meta();
        }
        
        // Always remove transients and cached data
        self::cleanup_transients();
        
        // Log uninstall
        self::log_uninstall();
    }
    
    /**
     * Delete plugin database tables
     */
    private static function delete_database_tables() {
        global $wpdb;
        
        // Delete receipts table
        $receipts_table = $wpdb->prefix . 'haiti_payment_receipts';
        $wpdb->query("DROP TABLE IF EXISTS `{$receipts_table}`");
        
        // Log table deletion
        error_log("WC Haiti: Deleted database table {$receipts_table}");
    }
    
    /**
     * Delete uploaded receipt files
     */
    private static function delete_uploaded_files() {
        $upload_dir = wp_upload_dir();
        $haiti_dir = $upload_dir['basedir'] . '/wc-haiti-receipts/';
        
        if (is_dir($haiti_dir)) {
            self::delete_directory_recursive($haiti_dir);
            error_log("WC Haiti: Deleted upload directory {$haiti_dir}");
        }
    }
    
    /**
     * Delete plugin options from WordPress
     */
    private static function delete_plugin_options() {
        $options_to_delete = array(
            // General settings
            'wc_haiti_usd_htg_rate',
            'wc_haiti_auto_approve',
            'wc_haiti_email_notifications',
            'wc_haiti_preserve_data_on_uninstall',
            
            // Plugin version and setup
            'wc_haiti_plugin_version',
            'wc_haiti_db_version',
            'wc_haiti_installed_date',
            
            // Payment gateway settings
            'woocommerce_haiti_natcash_settings',
            'woocommerce_haiti_sogebank_settings', 
            'woocommerce_haiti_unibank_settings',
            'woocommerce_haiti_unitransfert_settings',
            'woocommerce_haiti_western_union_settings',
            'woocommerce_haiti_cam_transfert_settings',
            'woocommerce_haiti_moneygram_settings',
            
            // Cache and temporary data
            'wc_haiti_stats_cache',
            'wc_haiti_last_cleanup',
            'wc_haiti_error_log'
        );
        
        foreach ($options_to_delete as $option) {
            delete_option($option);
        }
        
        // Delete any options that start with our prefix
        $wpdb = $GLOBALS['wpdb'];
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'wc_haiti_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'woocommerce_haiti_%'");
        
        error_log("WC Haiti: Deleted plugin options");
    }
    
    /**
     * Cleanup user meta data related to the plugin
     */
    private static function cleanup_user_meta() {
        global $wpdb;
        
        // Delete user meta related to our plugin
        $user_meta_keys = array(
            'wc_haiti_admin_notices_dismissed',
            'wc_haiti_last_receipt_view',
            'wc_haiti_dashboard_preferences'
        );
        
        foreach ($user_meta_keys as $meta_key) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->usermeta} WHERE meta_key = %s",
                $meta_key
            ));
        }
        
        error_log("WC Haiti: Cleaned up user meta data");
    }
    
    /**
     * Cleanup post meta data related to orders
     */
    private static function cleanup_post_meta() {
        global $wpdb;
        
        // Delete order meta related to Haiti payments
        $post_meta_keys = array(
            '_wc_haiti_payment_method',
            '_wc_haiti_receipt_id',
            '_wc_haiti_payment_verified',
            '_wc_haiti_payment_notes'
        );
        
        foreach ($post_meta_keys as $meta_key) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
                $meta_key
            ));
        }
        
        error_log("WC Haiti: Cleaned up post meta data");
    }
    
    /**
     * Cleanup transients and cached data
     */
    private static function cleanup_transients() {
        global $wpdb;
        
        // Delete transients
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wc_haiti_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wc_haiti_%'");
        
        // Clear object cache if available
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        error_log("WC Haiti: Cleaned up transients and cache");
    }
    
    /**
     * Recursively delete a directory and all its contents
     */
    private static function delete_directory_recursive($dir) {
        if (!is_dir($dir)) {
            return false;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        
        foreach ($files as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            
            if (is_dir($path)) {
                self::delete_directory_recursive($path);
            } else {
                unlink($path);
            }
        }
        
        return rmdir($dir);
    }
    
    /**
     * Log the uninstall process
     */
    private static function log_uninstall() {
        $log_data = array(
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'user_login' => wp_get_current_user()->user_login,
            'site_url' => get_site_url(),
            'plugin_version' => get_option('wc_haiti_plugin_version', '1.0.0')
        );
        
        // Log to WordPress error log
        error_log('WC Haiti Payment Methods Uninstalled: ' . json_encode($log_data));
        
        // Could also send to external logging service if needed
        // self::send_uninstall_telemetry($log_data);
    }
    
    /**
     * Check if WooCommerce orders exist with Haiti payment methods
     */
    private static function has_haiti_orders() {
        global $wpdb;
        
        $count = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->postmeta} pm 
            JOIN {$wpdb->posts} p ON pm.post_id = p.ID 
            WHERE p.post_type = 'shop_order' 
            AND pm.meta_key = '_payment_method' 
            AND pm.meta_value LIKE 'haiti_%'
        ");
        
        return (int) $count > 0;
    }
    
    /**
     * Export data before deletion (optional)
     */
    private static function export_data_before_deletion() {
        global $wpdb;
        
        // Only export if there's significant data
        if (!self::has_haiti_orders()) {
            return;
        }
        
        $upload_dir = wp_upload_dir();
        $export_file = $upload_dir['basedir'] . '/wc-haiti-export-' . date('Y-m-d-H-i-s') . '.json';
        
        // Get receipts data
        $receipts_table = $wpdb->prefix . 'haiti_payment_receipts';
        $receipts = $wpdb->get_results("SELECT * FROM {$receipts_table}", ARRAY_A);
        
        // Get plugin settings
        $settings = array();
        $wpdb_options = $wpdb->get_results("SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE 'wc_haiti_%' OR option_name LIKE 'woocommerce_haiti_%'", ARRAY_A);
        
        foreach ($wpdb_options as $option) {
            $settings[$option['option_name']] = maybe_unserialize($option['option_value']);
        }
        
        $export_data = array(
            'export_date' => current_time('mysql'),
            'plugin_version' => get_option('wc_haiti_plugin_version', '1.0.0'),
            'site_url' => get_site_url(),
            'receipts' => $receipts,
            'settings' => $settings
        );
        
        // Save export file
        file_put_contents($export_file, json_encode($export_data, JSON_PRETTY_PRINT));
        
        error_log("WC Haiti: Data exported to {$export_file}");
    }
    
    /**
     * Send uninstall feedback (optional)
     */
    private static function send_uninstall_telemetry($data) {
        // This could be used to collect anonymous uninstall data
        // for improving the plugin, but should be opt-in only
        
        $telemetry_enabled = get_option('wc_haiti_telemetry_enabled', false);
        
        if (!$telemetry_enabled) {
            return;
        }
        
        // Send anonymous data to telemetry endpoint
        wp_remote_post('https://telemetry.example.com/uninstall', array(
            'body' => json_encode($data),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 5
        ));
    }
    
    /**
     * Show uninstall confirmation message
     */
    public static function show_uninstall_message() {
        // This would be called if we had an admin interface for uninstall
        // Currently WordPress handles this automatically
        
        $message = __('WooCommerce Haiti Payment Methods has been completely removed from your site.', 'wc-haiti-payment-methods');
        
        if (self::has_haiti_orders()) {
            $message .= ' ' . __('Note: Some order data may still reference Haiti payment methods.', 'wc-haiti-payment-methods');
        }
        
        return $message;
    }
}

/**
 * Custom order status cleanup
 */
function wc_haiti_cleanup_custom_order_statuses() {
    global $wpdb;
    
    // Get orders with custom Haiti statuses
    $haiti_statuses = array(
        'wc-haiti-pending-payment',
        'wc-haiti-pending-verification', 
        'wc-haiti-payment-verified',
        'wc-haiti-payment-rejected'
    );
    
    foreach ($haiti_statuses as $status) {
        // Change custom statuses to standard WooCommerce statuses
        $new_status = 'wc-pending'; // Default fallback
        
        switch ($status) {
            case 'wc-haiti-payment-verified':
                $new_status = 'wc-processing';
                break;
            case 'wc-haiti-payment-rejected':
                $new_status = 'wc-cancelled';
                break;
        }
        
        $wpdb->update(
            $wpdb->posts,
            array('post_status' => $new_status),
            array('post_status' => $status),
            array('%s'),
            array('%s')
        );
    }
    
    error_log("WC Haiti: Converted custom order statuses to standard WooCommerce statuses");
}

/**
 * Backup critical data before uninstall
 */
function wc_haiti_backup_critical_data() {
    // Create a backup of critical data that merchants might need
    $backup_data = array(
        'payment_methods_config' => array(),
        'orders_with_haiti_payments' => array(),
        'receipts_summary' => array()
    );
    
    // Get payment method configurations
    $payment_methods = array('natcash', 'sogebank', 'unibank', 'unitransfert', 'western_union', 'cam_transfert', 'moneygram');
    
    foreach ($payment_methods as $method) {
        $settings = get_option("woocommerce_haiti_{$method}_settings", array());
        if (!empty($settings)) {
            $backup_data['payment_methods_config'][$method] = $settings;
        }
    }
    
    // Get summary of orders (not detailed data for privacy)
    global $wpdb;
    $orders_summary = $wpdb->get_results("
        SELECT pm.meta_value as payment_method, COUNT(*) as count, MIN(p.post_date) as first_order, MAX(p.post_date) as last_order
        FROM {$wpdb->postmeta} pm 
        JOIN {$wpdb->posts} p ON pm.post_id = p.ID 
        WHERE p.post_type = 'shop_order' 
        AND pm.meta_key = '_payment_method' 
        AND pm.meta_value LIKE 'haiti_%'
        GROUP BY pm.meta_value
    ", ARRAY_A);
    
    $backup_data['orders_with_haiti_payments'] = $orders_summary;
    
    // Save backup
    $upload_dir = wp_upload_dir();
    $backup_file = $upload_dir['basedir'] . '/wc-haiti-backup-' . date('Y-m-d-H-i-s') . '.json';
    file_put_contents($backup_file, json_encode($backup_data, JSON_PRETTY_PRINT));
    
    // Set an option so admin knows about the backup
    update_option('wc_haiti_backup_file', $backup_file, false);
    
    error_log("WC Haiti: Critical data backed up to {$backup_file}");
}

// Execute uninstall
try {
    // Backup critical data first
    wc_haiti_backup_critical_data();
    
    // Cleanup custom order statuses
    wc_haiti_cleanup_custom_order_statuses();
    
    // Run main uninstall process
    WC_Haiti_Uninstaller::uninstall();
    
    // Flush rewrite rules
    flush_rewrite_rules();
    
    error_log("WC Haiti Payment Methods: Uninstall completed successfully");
    
} catch (Exception $e) {
    error_log("WC Haiti Payment Methods: Uninstall error - " . $e->getMessage());
    
    // Continue with basic cleanup even if advanced cleanup fails
    delete_option('wc_haiti_usd_htg_rate');
    delete_option('wc_haiti_auto_approve');
    delete_option('wc_haiti_email_notifications');
}

// Clear any remaining scheduled events
wp_clear_scheduled_hook('wc_haiti_cleanup_old_receipts');
wp_clear_scheduled_hook('wc_haiti_send_pending_notifications');

// Final cleanup
if (function_exists('wp_cache_flush')) {
    wp_cache_flush();
}
