<?php
/**
 * Payment instructions email template
 */

if (!defined('ABSPATH')) {
    exit;
}

$order_number = $order->get_order_number();
$customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
$order_total = $order->get_formatted_order_total();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php printf(__('Instructions de paiement - Commande #%s', 'wc-haiti-payment-methods'), $order_number); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #0073aa;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #0073aa;
        }
        .order-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .payment-details {
            background-color: #e8f4f8;
            padding: 20px;
            border-radius: 5px;
            border-left: 4px solid #0073aa;
            margin: 20px 0;
        }
        .payment-method {
            font-size: 18px;
            font-weight: bold;
            color: #0073aa;
            margin-bottom: 15px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dotted #ccc;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: bold;
        }
        .value {
            color: #666;
        }
        .amount {
            background-color: #fff3cd;
            color: #856404;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin: 15px 0;
        }
        .instructions {
            margin: 20px 0;
        }
        .step {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .step:last-child {
            border-bottom: none;
        }
        .step-number {
            display: inline-block;
            background-color: #0073aa;
            color: white;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            text-align: center;
            line-height: 25px;
            margin-right: 10px;
            font-weight: bold;
        }
        .important {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="logo"><?php echo get_bloginfo('name'); ?></div>
            <h2><?php _e('Instructions de paiement', 'wc-haiti-payment-methods'); ?></h2>
        </div>
        
        <p><?php printf(__('Bonjour %s,', 'wc-haiti-payment-methods'), esc_html($customer_name)); ?></p>
        
        <p><?php printf(__('Merci pour votre commande #%s. Veuillez suivre les instructions ci-dessous pour effectuer votre paiement.', 'wc-haiti-payment-methods'), $order_number); ?></p>
        
        <div class="order-info">
            <div class="info-row">
                <span class="label"><?php _e('Numéro de commande:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value">#<?php echo esc_html($order_number); ?></span>
            </div>
            <div class="info-row">
                <span class="label"><?php _e('Date de commande:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($order->get_date_created()->date_i18n(get_option('date_format'))); ?></span>
            </div>
            <div class="info-row">
                <span class="label"><?php _e('Montant total:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo wp_kses_post($order_total); ?></span>
            </div>
        </div>
        
        <div class="payment-details">
            <?php
            // Get payment method details
            if ($payment_method === 'haiti_natcash'):
                $gateway = WC()->payment_gateways()->payment_gateways()['haiti_natcash'];
                $htg_amount = $gateway->convert_usd_to_htg($order->get_total());
            ?>
                <div class="payment-method"><?php _e('Paiement NATCASH', 'wc-haiti-payment-methods'); ?></div>
                
                <div class="info-row">
                    <span class="label"><?php _e('Numéro NATCASH:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('natcash_number')); ?></span>
                </div>
                
                <div class="info-row">
                    <span class="label"><?php _e('Nom du compte:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('account_name')); ?></span>
                </div>
                
                <div class="amount"><?php printf(__('Montant à payer: %s HTG', 'wc-haiti-payment-methods'), number_format($htg_amount, 2)); ?></div>
                
                <div class="instructions">
                    <h4><?php _e('Instructions:', 'wc-haiti-payment-methods'); ?></h4>
                    <div class="step">
                        <span class="step-number">1</span>
                        <?php _e('Ouvrez votre application NATCASH', 'wc-haiti-payment-methods'); ?>
                    </div>
                    <div class="step">
                        <span class="step-number">2</span>
                        <?php printf(__('Envoyez %s HTG au numéro %s', 'wc-haiti-payment-methods'), number_format($htg_amount, 2), esc_html($gateway->get_option('natcash_number'))); ?>
                    </div>
                    <div class="step">
                        <span class="step-number">3</span>
                        <?php _e('Prenez une capture d\'écran de la confirmation', 'wc-haiti-payment-methods'); ?>
                    </div>
                    <div class="step">
                        <span class="step-number">4</span>
                        <?php _e('Téléchargez votre reçu sur notre site', 'wc-haiti-payment-methods'); ?>
                    </div>
                </div>
                
            <?php elseif (in_array($payment_method, ['haiti_sogebank', 'haiti_unibank'])): ?>
                <?php $gateway = WC()->payment_gateways()->payment_gateways()[$payment_method]; ?>
                
                <div class="payment-method"><?php printf(__('Virement bancaire %s', 'wc-haiti-payment-methods'), $gateway->method_title); ?></div>
                
                <div class="info-row">
                    <span class="label"><?php _e('Bénéficiaire:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('beneficiary_name')); ?></span>
                </div>
                
                <div class="info-row">
                    <span class="label"><?php _e('Numéro de compte:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('account_number')); ?></span>
                </div>
                
                <?php if ($gateway->get_option('swift_code')): ?>
                <div class="info-row">
                    <span class="label"><?php _e('Code SWIFT:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('swift_code')); ?></span>
                </div>
                <?php endif; ?>
                
                <div class="amount"><?php printf(__('Montant à virer: %s', 'wc-haiti-payment-methods'), wp_kses_post($order_total)); ?></div>
                
            <?php else: ?>
                <?php $gateway = WC()->payment_gateways()->payment_gateways()[$payment_method]; ?>
                
                <div class="payment-method"><?php printf(__('Transfert %s', 'wc-haiti-payment-methods'), $gateway->method_title); ?></div>
                
                <div class="info-row">
                    <span class="label"><?php _e('Bénéficiaire:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('beneficiary_full_name')); ?></span>
                </div>
                
                <div class="info-row">
                    <span class="label"><?php _e('Pays:', 'wc-haiti-payment-methods'); ?></span>
                    <span class="value"><?php echo esc_html($gateway->get_option('beneficiary_country')); ?></span>
                </div>
                
                <div class="amount"><?php printf(__('Montant à envoyer: %s', 'wc-haiti-payment-methods'), wp_kses_post($order_total)); ?></div>
                
            <?php endif; ?>
        </div>
        
        <div class="important">
            <strong><?php _e('Important:', 'wc-haiti-payment-methods'); ?></strong>
            <?php _e('Après avoir effectué votre paiement, vous devez télécharger votre reçu sur notre site pour que nous puissions traiter votre commande. Votre commande sera mise en attente jusqu\'à réception et vérification de votre reçu.', 'wc-haiti-payment-methods'); ?>
        </div>
        
        <p>
            <a href="<?php echo esc_url($order->get_checkout_order_received_url()); ?>" style="background-color: #0073aa; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                <?php _e('Voir ma commande', 'wc-haiti-payment-methods'); ?>
            </a>
        </p>
        
        <div class="footer">
            <p><?php _e('Si vous avez des questions, n\'hésitez pas à nous contacter.', 'wc-haiti-payment-methods'); ?></p>
            <p><?php printf(__('Cordialement,<br>L\'équipe %s', 'wc-haiti-payment-methods'), get_bloginfo('name')); ?></p>
        </div>
    </div>
</body>
</html>
