<?php
/**
 * Receipt validation email template
 */

if (!defined('ABSPATH')) {
    exit;
}

$order_number = $order->get_order_number();
$customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
$is_approved = ($status === 'approved');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php printf(__('%s - Commande #%s', 'wc-haiti-payment-methods'), $is_approved ? __('Paiement approuvé', 'wc-haiti-payment-methods') : __('Paiement rejeté', 'wc-haiti-payment-methods'), $order_number); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .header.approved {
            border-bottom: 2px solid #46b450;
        }
        .header.rejected {
            border-bottom: 2px solid #dc3232;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
        }
        .logo.approved {
            color: #46b450;
        }
        .logo.rejected {
            color: #dc3232;
        }
        .status-badge {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: bold;
            font-size: 16px;
            margin: 15px 0;
        }
        .status-badge.approved {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .status-badge.rejected {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .order-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dotted #ccc;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: bold;
        }
        .value {
            color: #666;
        }
        .message-box {
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .message-box.approved {
            background-color: #d4edda;
            border-left: 4px solid #46b450;
        }
        .message-box.rejected {
            background-color: #f8d7da;
            border-left: 4px solid #dc3232;
        }
        .admin-notes {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            border-left: 4px solid #6c757d;
        }
        .next-steps {
            background-color: #fff3cd;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #ffc107;
            margin: 20px 0;
        }
        .button {
            display: inline-block;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            margin: 10px 5px;
        }
        .button.primary {
            background-color: #0073aa;
            color: white;
        }
        .button.success {
            background-color: #46b450;
            color: white;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header <?php echo $is_approved ? 'approved' : 'rejected'; ?>">
            <div class="logo <?php echo $is_approved ? 'approved' : 'rejected'; ?>"><?php echo get_bloginfo('name'); ?></div>
            <h2>
                <?php if ($is_approved): ?>
                    <?php _e('Paiement Approuvé', 'wc-haiti-payment-methods'); ?>
                <?php else: ?>
                    <?php _e('Paiement Rejeté', 'wc-haiti-payment-methods'); ?>
                <?php endif; ?>
            </h2>
            <div class="status-badge <?php echo $is_approved ? 'approved' : 'rejected'; ?>">
                <?php if ($is_approved): ?>
                    ✓ <?php _e('APPROUVÉ', 'wc-haiti-payment-methods'); ?>
                <?php else: ?>
                    ✗ <?php _e('REJETÉ', 'wc-haiti-payment-methods'); ?>
                <?php endif; ?>
            </div>
        </div>
        
        <p><?php printf(__('Bonjour %s,', 'wc-haiti-payment-methods'), esc_html($customer_name)); ?></p>
        
        <div class="order-info">
            <div class="info-row">
                <span class="label"><?php _e('Numéro de commande:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value">#<?php echo esc_html($order_number); ?></span>
            </div>
            <div class="info-row">
                <span class="label"><?php _e('Date de vérification:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format')); ?></span>
            </div>
            <div class="info-row">
                <span class="label"><?php _e('Montant:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></span>
            </div>
        </div>
        
        <?php if ($is_approved): ?>
            <div class="message-box approved">
                <h3><?php _e('Excellent ! Votre paiement a été approuvé.', 'wc-haiti-payment-methods'); ?></h3>
                <p><?php printf(__('Nous avons vérifié et approuvé votre reçu de paiement pour la commande #%s. Votre commande est maintenant en cours de traitement.', 'wc-haiti-payment-methods'), $order_number); ?></p>
            </div>
            
            <?php if ($admin_notes): ?>
            <div class="admin-notes">
                <h4><?php _e('Notes de l\'administrateur:', 'wc-haiti-payment-methods'); ?></h4>
                <p><?php echo esc_html($admin_notes); ?></p>
            </div>
            <?php endif; ?>
            
            <div class="next-steps">
                <h4><?php _e('Prochaines étapes:', 'wc-haiti-payment-methods'); ?></h4>
                <ul>
                    <li><?php _e('Votre commande est maintenant confirmée et en cours de traitement', 'wc-haiti-payment-methods'); ?></li>
                    <li><?php _e('Vous recevrez un email de confirmation d\'expédition avec le numéro de suivi', 'wc-haiti-payment-methods'); ?></li>
                    <li><?php _e('Vous pouvez suivre l\'état de votre commande dans votre compte client', 'wc-haiti-payment-methods'); ?></li>
                </ul>
            </div>
            
            <p style="text-align: center;">
                <a href="<?php echo esc_url($order->get_view_order_url()); ?>" class="button success">
                    <?php _e('Voir ma commande', 'wc-haiti-payment-methods'); ?>
                </a>
                <a href="<?php echo esc_url(wc_get_account_endpoint_url('orders')); ?>" class="button primary">
                    <?php _e('Mes commandes', 'wc-haiti-payment-methods'); ?>
                </a>
            </p>
            
        <?php else: ?>
            <div class="message-box rejected">
                <h3><?php _e('Votre paiement a été rejeté.', 'wc-haiti-payment-methods'); ?></h3>
                <p><?php printf(__('Nous avons examiné votre reçu de paiement pour la commande #%s, mais nous ne pouvons pas l\'approuver pour les raisons mentionnées ci-dessous.', 'wc-haiti-payment-methods'), $order_number); ?></p>
            </div>
            
            <?php if ($admin_notes): ?>
            <div class="admin-notes">
                <h4><?php _e('Raison du rejet:', 'wc-haiti-payment-methods'); ?></h4>
                <p><?php echo esc_html($admin_notes); ?></p>
            </div>
            <?php endif; ?>
            
            <div class="next-steps">
                <h4><?php _e('Que faire maintenant ?', 'wc-haiti-payment-methods'); ?></h4>
                <ul>
                    <li><?php _e('Vérifiez les informations de paiement et effectuez un nouveau paiement si nécessaire', 'wc-haiti-payment-methods'); ?></li>
                    <li><?php _e('Téléchargez un nouveau reçu plus lisible si le problème concerne la qualité de l\'image', 'wc-haiti-payment-methods'); ?></li>
                    <li><?php _e('Contactez notre service client si vous avez des questions', 'wc-haiti-payment-methods'); ?></li>
                </ul>
            </div>
            
            <p style="text-align: center;">
                <a href="<?php echo esc_url($order->get_view_order_url()); ?>" class="button primary">
                    <?php _e('Voir ma commande', 'wc-haiti-payment-methods'); ?>
                </a>
            </p>
        <?php endif; ?>
        
        <div class="footer">
            <p><?php _e('Si vous avez des questions concernant cette décision, n\'hésitez pas à nous contacter.', 'wc-haiti-payment-methods'); ?></p>
            <p><?php printf(__('Cordialement,<br>L\'équipe %s', 'wc-haiti-payment-methods'), get_bloginfo('name')); ?></p>
        </div>
    </div>
</body>
</html>
