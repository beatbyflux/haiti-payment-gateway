<?php
/**
 * Bank payment fields template (SOGEBANK/UNIBANK)
 */

if (!defined('ABSPATH')) {
    exit;
}

$order_total = WC()->cart->get_total('raw');
$bank_name = $this->method_title;
?>

<div class="wc-haiti-payment-fields bank-payment">
    <div class="wc-haiti-payment-header">
        <h4><?php printf(__('Virement bancaire %s', 'wc-haiti-payment-methods'), $bank_name); ?></h4>
        <p class="description"><?php printf(__('Effectuez un virement bancaire vers notre compte %s', 'wc-haiti-payment-methods'), $bank_name); ?></p>
    </div>
    
    <div class="wc-haiti-payment-info">
        <div class="payment-info-row">
            <span class="label"><?php _e('Banque:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($bank_name); ?></span>
        </div>
        
        <div class="payment-info-row">
            <span class="label"><?php _e('Bénéficiaire:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($this->get_option('beneficiary_name')); ?></span>
        </div>
        
        <div class="payment-info-row">
            <span class="label"><?php _e('Numéro de compte:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value account-number"><?php echo esc_html($this->get_option('account_number')); ?></span>
        </div>
        
        <?php if ($this->get_option('bank_address')): ?>
        <div class="payment-info-row">
            <span class="label"><?php _e('Adresse de la banque:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($this->get_option('bank_address')); ?></span>
        </div>
        <?php endif; ?>
        
        <?php if ($this->get_option('swift_code')): ?>
        <div class="payment-info-row">
            <span class="label"><?php _e('Code SWIFT:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($this->get_option('swift_code')); ?></span>
        </div>
        <?php endif; ?>
        
        <div class="payment-info-row amount-row">
            <span class="label"><?php _e('Montant à virer:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value amount-usd">$<?php echo number_format($order_total, 2); ?> USD</span>
        </div>
    </div>
    
    <div class="wc-haiti-instructions">
        <h5><?php _e('Instructions de paiement:', 'wc-haiti-payment-methods'); ?></h5>
        <ol class="payment-steps">
            <li>
                <span class="step-number">1</span>
                <span class="step-text"><?php printf(__('Rendez-vous dans une succursale %s ou utilisez votre banque en ligne', 'wc-haiti-payment-methods'), $bank_name); ?></span>
            </li>
            <li>
                <span class="step-number">2</span>
                <span class="step-text"><?php _e('Effectuez un virement bancaire en utilisant les informations ci-dessus', 'wc-haiti-payment-methods'); ?></span>
            </li>
            <li>
                <span class="step-number">3</span>
                <span class="step-text"><?php _e('Conservez votre reçu de transaction bancaire', 'wc-haiti-payment-methods'); ?></span>
            </li>
            <li>
                <span class="step-number">4</span>
                <span class="step-text"><?php _e('Téléchargez une copie de votre reçu ci-dessous', 'wc-haiti-payment-methods'); ?></span>
            </li>
        </ol>
    </div>
    
    <div class="wc-haiti-important-note">
        <p class="note">
            <strong><?php _e('Important:', 'wc-haiti-payment-methods'); ?></strong>
            <?php _e('Assurez-vous que le montant exact est viré et que toutes les informations sont correctes. Les frais bancaires sont à votre charge.', 'wc-haiti-payment-methods'); ?>
        </p>
    </div>
    
    <?php include WC_HAITI_PLUGIN_PATH . 'templates/checkout/receipt-upload.php'; ?>
</div>
