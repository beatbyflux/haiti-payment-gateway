<?php
/**
 * NATCASH payment fields template
 */

if (!defined('ABSPATH')) {
    exit;
}

$order_total = WC()->cart->get_total('raw');
$htg_amount = $this->convert_usd_to_htg($order_total);
?>

<div class="wc-haiti-payment-fields natcash-payment">
    <div class="wc-haiti-payment-header">
        <h4><?php _e('Paiement NATCASH', 'wc-haiti-payment-methods'); ?></h4>
        <p class="description"><?php _e('Effectuez votre paiement via l\'application mobile NATCASH', 'wc-haiti-payment-methods'); ?></p>
    </div>
    
    <div class="wc-haiti-payment-info">
        <div class="payment-info-row">
            <span class="label"><?php _e('Numéro NATCASH:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($this->get_option('natcash_number')); ?></span>
        </div>
        
        <div class="payment-info-row">
            <span class="label"><?php _e('Nom du compte:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($this->get_option('account_name')); ?></span>
        </div>
        
        <div class="payment-info-row amount-row">
            <span class="label"><?php _e('Montant à payer:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value amount-htg"><?php echo number_format($htg_amount, 2); ?> HTG</span>
        </div>
        
        <div class="payment-info-row">
            <span class="label"><?php _e('Équivalent USD:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value">$<?php echo number_format($order_total, 2); ?> USD</span>
        </div>
    </div>
    
    <div class="wc-haiti-instructions">
        <h5><?php _e('Instructions de paiement:', 'wc-haiti-payment-methods'); ?></h5>
        <ol class="payment-steps">
            <li>
                <span class="step-number">1</span>
                <span class="step-text"><?php _e('Ouvrez votre application NATCASH sur votre téléphone', 'wc-haiti-payment-methods'); ?></span>
            </li>
            <li>
                <span class="step-number">2</span>
                <span class="step-text"><?php printf(__('Sélectionnez "Envoyer de l\'argent" et envoyez %s HTG au numéro %s', 'wc-haiti-payment-methods'), '<strong>' . number_format($htg_amount, 2) . '</strong>', '<strong>' . esc_html($this->get_option('natcash_number')) . '</strong>'); ?></span>
            </li>
            <li>
                <span class="step-number">3</span>
                <span class="step-text"><?php _e('Prenez une capture d\'écran de la confirmation de paiement', 'wc-haiti-payment-methods'); ?></span>
            </li>
            <li>
                <span class="step-number">4</span>
                <span class="step-text"><?php _e('Téléchargez votre reçu ci-dessous', 'wc-haiti-payment-methods'); ?></span>
            </li>
        </ol>
    </div>
    
    <div class="wc-haiti-conversion-note">
        <p class="note">
            <strong><?php _e('Note:', 'wc-haiti-payment-methods'); ?></strong>
            <?php printf(__('Le montant a été converti automatiquement au taux de %s HTG pour 1 USD.', 'wc-haiti-payment-methods'), number_format($this->usd_to_htg_rate, 2)); ?>
        </p>
    </div>
    
    <?php include WC_HAITI_PLUGIN_PATH . 'templates/checkout/receipt-upload.php'; ?>
</div>
