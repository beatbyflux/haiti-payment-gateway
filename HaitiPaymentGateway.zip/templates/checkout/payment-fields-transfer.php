<?php
/**
 * Transfer services payment fields template (Western Union, MoneyGram, etc.)
 */

if (!defined('ABSPATH')) {
    exit;
}

$order_total = WC()->cart->get_total('raw');
$service_name = $this->method_title;
?>

<div class="wc-haiti-payment-fields transfer-payment">
    <div class="wc-haiti-payment-header">
        <h4><?php printf(__('Transfert %s', 'wc-haiti-payment-methods'), $service_name); ?></h4>
        <p class="description"><?php printf(__('Envoyez de l\'argent via %s en utilisant les informations ci-dessous', 'wc-haiti-payment-methods'), $service_name); ?></p>
    </div>
    
    <div class="wc-haiti-payment-info">
        <div class="payment-info-row">
            <span class="label"><?php _e('Service de transfert:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value"><?php echo esc_html($service_name); ?></span>
        </div>
        
        <div class="payment-info-section">
            <h5><?php _e('Informations du bénéficiaire:', 'wc-haiti-payment-methods'); ?></h5>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Nom complet:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_full_name')); ?></span>
            </div>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Prénom:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_first_name')); ?></span>
            </div>
            
            <?php if ($this->get_option('beneficiary_birth_date')): ?>
            <div class="payment-info-row">
                <span class="label"><?php _e('Date de naissance:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($this->get_option('beneficiary_birth_date')))); ?></span>
            </div>
            <?php endif; ?>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Pays:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_country')); ?></span>
            </div>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Ville/Département:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_city')); ?></span>
            </div>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Adresse:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_address')); ?></span>
            </div>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Téléphone:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_phone')); ?></span>
            </div>
            
            <div class="payment-info-row">
                <span class="label"><?php _e('Profession:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_profession')); ?></span>
            </div>
            
            <?php if ($this->get_option('beneficiary_id')): ?>
            <div class="payment-info-row">
                <span class="label"><?php _e('Pièce d\'identité:', 'wc-haiti-payment-methods'); ?></span>
                <span class="value"><?php echo esc_html($this->get_option('beneficiary_id')); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="payment-info-row amount-row">
            <span class="label"><?php _e('Montant à envoyer:', 'wc-haiti-payment-methods'); ?></span>
            <span class="value amount-usd">$<?php echo number_format($order_total, 2); ?> USD</span>
        </div>
    </div>
    
    <div class="wc-haiti-instructions">
        <h5><?php _e('Instructions de paiement:', 'wc-haiti-payment-methods'); ?></h5>
        <ol class="payment-steps">
            <li>
                <span class="step-number">1</span>
                <span class="step-text"><?php printf(__('Rendez-vous dans un bureau %s près de chez vous', 'wc-haiti-payment-methods'), $service_name); ?></span>
            </li>
            <li>
                <span class="step-number">2</span>
                <span class="step-text"><?php _e('Utilisez exactement les informations du bénéficiaire ci-dessus', 'wc-haiti-payment-methods'); ?></span>
            </li>
            <li>
                <span class="step-number">3</span>
                <span class="step-text"><?php printf(__('Envoyez %s USD', 'wc-haiti-payment-methods'), number_format($order_total, 2)); ?></span>
            </li>
            <li>
                <span class="step-number">4</span>
                <span class="step-text">
                    <?php if (strpos(strtolower($service_name), 'western union') !== false): ?>
                        <?php _e('Conservez votre reçu avec le numéro MTCN', 'wc-haiti-payment-methods'); ?>
                    <?php elseif (strpos(strtolower($service_name), 'moneygram') !== false): ?>
                        <?php _e('Conservez votre reçu avec le numéro de référence MoneyGram', 'wc-haiti-payment-methods'); ?>
                    <?php else: ?>
                        <?php _e('Conservez votre reçu de transfert avec le numéro de référence', 'wc-haiti-payment-methods'); ?>
                    <?php endif; ?>
                </span>
            </li>
            <li>
                <span class="step-number">5</span>
                <span class="step-text"><?php _e('Téléchargez une copie de votre reçu ci-dessous', 'wc-haiti-payment-methods'); ?></span>
            </li>
        </ol>
    </div>
    
    <div class="wc-haiti-important-note">
        <p class="note">
            <strong><?php _e('Important:', 'wc-haiti-payment-methods'); ?></strong>
            <?php _e('Vérifiez que toutes les informations du bénéficiaire sont exactes avant d\'effectuer le transfert. Les frais de transfert sont à votre charge.', 'wc-haiti-payment-methods'); ?>
        </p>
    </div>
    
    <?php include WC_HAITI_PLUGIN_PATH . 'templates/checkout/receipt-upload.php'; ?>
</div>
