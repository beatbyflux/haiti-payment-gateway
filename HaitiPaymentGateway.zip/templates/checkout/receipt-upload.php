<?php
/**
 * Receipt upload form template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wc-haiti-receipt-upload">
    <h5><?php _e('Télécharger votre reçu de paiement', 'wc-haiti-payment-methods'); ?></h5>
    
    <div class="upload-section">
        <div class="upload-instructions">
            <p><?php _e('Téléchargez une photo ou un scan de votre reçu de paiement:', 'wc-haiti-payment-methods'); ?></p>
            <ul class="upload-requirements">
                <li><?php _e('Formats acceptés: JPG, PNG, PDF', 'wc-haiti-payment-methods'); ?></li>
                <li><?php _e('Taille maximale: 5MB', 'wc-haiti-payment-methods'); ?></li>
                <li><?php _e('Le reçu doit être lisible et complet', 'wc-haiti-payment-methods'); ?></li>
            </ul>
        </div>
        
        <div class="upload-area">
            <div class="file-drop-zone" id="wc-haiti-drop-zone">
                <div class="drop-zone-content">
                    <svg class="upload-icon" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7,10 12,15 17,10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                    <p class="drop-text"><?php _e('Glissez votre fichier ici ou cliquez pour sélectionner', 'wc-haiti-payment-methods'); ?></p>
                    <button type="button" class="button upload-button"><?php _e('Sélectionner un fichier', 'wc-haiti-payment-methods'); ?></button>
                </div>
                <input type="file" name="wc_haiti_receipt" id="wc-haiti-receipt-file" accept=".jpg,.jpeg,.png,.pdf" required style="display: none;" />
            </div>
            
            <div class="file-preview" id="wc-haiti-file-preview" style="display: none;">
                <div class="preview-content">
                    <div class="file-info">
                        <span class="file-name"></span>
                        <span class="file-size"></span>
                    </div>
                    <button type="button" class="remove-file" title="<?php _e('Supprimer le fichier', 'wc-haiti-payment-methods'); ?>">&times;</button>
                </div>
            </div>
        </div>
        
        <div class="upload-progress" id="wc-haiti-upload-progress" style="display: none;">
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
            <span class="progress-text">0%</span>
        </div>
        
        <div class="upload-messages" id="wc-haiti-upload-messages"></div>
    </div>
    
    <div class="verification-note">
        <p class="note">
            <strong><?php _e('Vérification:', 'wc-haiti-payment-methods'); ?></strong>
            <?php _e('Votre reçu sera examiné par notre équipe dans les 24 heures. Vous recevrez une confirmation par email une fois le paiement vérifié.', 'wc-haiti-payment-methods'); ?>
        </p>
    </div>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    var $dropZone = $('#wc-haiti-drop-zone');
    var $fileInput = $('#wc-haiti-receipt-file');
    var $filePreview = $('#wc-haiti-file-preview');
    var $uploadProgress = $('#wc-haiti-upload-progress');
    var $uploadMessages = $('#wc-haiti-upload-messages');
    
    // Click to select file
    $dropZone.on('click', '.upload-button', function(e) {
        e.preventDefault();
        $fileInput.click();
    });
    
    // Drag and drop
    $dropZone.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });
    
    $dropZone.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
    });
    
    $dropZone.on('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        
        var files = e.originalEvent.dataTransfer.files;
        if (files.length > 0) {
            handleFileSelect(files[0]);
        }
    });
    
    // File input change
    $fileInput.on('change', function() {
        if (this.files.length > 0) {
            handleFileSelect(this.files[0]);
        }
    });
    
    // Remove file
    $filePreview.on('click', '.remove-file', function() {
        clearFileSelection();
    });
    
    function handleFileSelect(file) {
        // Validate file
        var validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        var maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!validTypes.includes(file.type)) {
            showMessage('<?php _e('Type de fichier non autorisé. Utilisez JPG, PNG ou PDF.', 'wc-haiti-payment-methods'); ?>', 'error');
            return;
        }
        
        if (file.size > maxSize) {
            showMessage('<?php _e('Fichier trop volumineux. Taille maximale: 5MB.', 'wc-haiti-payment-methods'); ?>', 'error');
            return;
        }
        
        // Show preview
        showFilePreview(file);
        
        // Update file input
        var dt = new DataTransfer();
        dt.items.add(file);
        $fileInput[0].files = dt.files;
        
        clearMessages();
    }
    
    function showFilePreview(file) {
        var fileSize = formatFileSize(file.size);
        
        $filePreview.find('.file-name').text(file.name);
        $filePreview.find('.file-size').text('(' + fileSize + ')');
        
        $dropZone.hide();
        $filePreview.show();
    }
    
    function clearFileSelection() {
        $fileInput.val('');
        $filePreview.hide();
        $dropZone.show();
        clearMessages();
    }
    
    function showMessage(message, type) {
        var className = type === 'error' ? 'error-message' : 'success-message';
        $uploadMessages.html('<div class="' + className + '">' + message + '</div>');
    }
    
    function clearMessages() {
        $uploadMessages.empty();
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        var k = 1024;
        var sizes = ['Bytes', 'KB', 'MB', 'GB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
});
</script>
