<?php
/**
 * Email notifications
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Emails class
 */
class WC_Haiti_Emails {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Initialize email hooks
    }
    
    /**
     * Send payment instructions email
     */
    public static function send_payment_instructions($order, $payment_method) {
        $to = $order->get_billing_email();
        $subject = sprintf(__('Instructions de paiement pour la commande #%s', 'wc-haiti-payment-methods'), $order->get_order_number());
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        // Get payment gateway instance
        $gateways = WC()->payment_gateways()->payment_gateways();
        $gateway = isset($gateways[$payment_method]) ? $gateways[$payment_method] : null;
        
        $payment_data = $gateway ? $gateway->get_payment_data() : array();
        
        ob_start();
        include WC_HAITI_PLUGIN_PATH . 'templates/emails/payment-instructions.php';
        $message = ob_get_clean();
        
        wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Send new receipt notification to admin
     */
    public static function send_new_receipt_notification($order, $receipt_id) {
        $admin_email = get_option('admin_email');
        $subject = sprintf(__('Nouveau reçu de paiement - Commande #%s', 'wc-haiti-payment-methods'), $order->get_order_number());
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        $receipt = WC_Haiti_Receipt_Handler::get_receipt($receipt_id);
        
        $message = sprintf(
            __('Un nouveau reçu de paiement a été téléchargé pour la commande #%s.<br><br>
            <strong>Détails:</strong><br>
            - Méthode de paiement: %s<br>
            - Client: %s %s<br>
            - Email: %s<br>
            - Montant: %s<br><br>
            <a href="%s">Gérer les reçus</a>', 'wc-haiti-payment-methods'),
            $order->get_order_number(),
            $receipt->payment_method,
            $order->get_billing_first_name(),
            $order->get_billing_last_name(),
            $order->get_billing_email(),
            $order->get_formatted_order_total(),
            admin_url('admin.php?page=wc-haiti-receipts')
        );
        
        wp_mail($admin_email, $subject, $message, $headers);
    }
    
    /**
     * Send receipt validation notification to customer
     */
    public static function send_receipt_validation_notification($order, $status, $admin_notes = '') {
        $to = $order->get_billing_email();
        
        if ($status === 'approved') {
            $subject = sprintf(__('Paiement approuvé - Commande #%s', 'wc-haiti-payment-methods'), $order->get_order_number());
        } else {
            $subject = sprintf(__('Paiement rejeté - Commande #%s', 'wc-haiti-payment-methods'), $order->get_order_number());
        }
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        ob_start();
        include WC_HAITI_PLUGIN_PATH . 'templates/emails/receipt-validation.php';
        $message = ob_get_clean();
        
        wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Send order status change notification
     */
    public static function send_order_status_notification($order, $old_status, $new_status) {
        $to = $order->get_billing_email();
        $subject = sprintf(__('Mise à jour de votre commande #%s', 'wc-haiti-payment-methods'), $order->get_order_number());
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        $status_messages = array(
            'wc-haiti-pending-payment' => __('Votre commande est en attente de paiement.', 'wc-haiti-payment-methods'),
            'wc-haiti-pending-verification' => __('Votre paiement est en cours de vérification.', 'wc-haiti-payment-methods'),
            'wc-haiti-payment-verified' => __('Votre paiement a été vérifié et votre commande est en cours de traitement.', 'wc-haiti-payment-methods'),
            'wc-haiti-payment-rejected' => __('Votre paiement a été rejeté. Veuillez nous contacter.', 'wc-haiti-payment-methods'),
        );
        
        $message = sprintf(
            __('Bonjour %s,<br><br>Le statut de votre commande #%s a été mis à jour.<br><br>%s<br><br>Cordialement,<br>L\'équipe', 'wc-haiti-payment-methods'),
            $order->get_billing_first_name(),
            $order->get_order_number(),
            isset($status_messages[$new_status]) ? $status_messages[$new_status] : __('Statut mis à jour.', 'wc-haiti-payment-methods')
        );
        
        wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Get email template
     */
    private static function get_email_template($template_name, $variables = array()) {
        extract($variables);
        
        ob_start();
        include WC_HAITI_PLUGIN_PATH . 'templates/emails/' . $template_name . '.php';
        return ob_get_clean();
    }
    
    /**
     * Format email with WooCommerce styling
     */
    private static function format_email($content) {
        return '
        <div style="background-color: #f7f7f7; padding: 20px;">
            <div style="background-color: #ffffff; padding: 20px; border-radius: 5px; max-width: 600px; margin: 0 auto;">
                ' . $content . '
            </div>
        </div>';
    }
}
