<?php
/**
 * NATCASH Payment Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Natcash_Gateway class
 */
class WC_Haiti_Natcash_Gateway extends WC_Haiti_Payment_Gateway {
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->id = 'haiti_natcash';
        $this->icon = '';
        $this->method_title = __('NATCASH', 'wc-haiti-payment-methods');
        $this->method_description = __('Paiement via portefeuille mobile NATCASH', 'wc-haiti-payment-methods');
        
        parent::__construct();
    }
    
    /**
     * Initialize gateway settings form fields
     */
    public function init_form_fields() {
        parent::init_form_fields();
        
        $this->form_fields = array_merge($this->form_fields, array(
            'account_section' => array(
                'title' => __('Informations du compte NATCASH', 'wc-haiti-payment-methods'),
                'type' => 'title',
                'description' => '',
            ),
            'natcash_number' => array(
                'title' => __('Numéro NATCASH', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Votre numéro de compte NATCASH', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'account_name' => array(
                'title' => __('Nom du compte', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Nom du titulaire du compte NATCASH', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
        ));
    }
    
    /**
     * Render payment fields
     */
    protected function render_payment_fields() {
        $order_total = WC()->cart->get_total('raw');
        $htg_amount = $this->convert_usd_to_htg($order_total);
        
        $template_path = WC_HAITI_PLUGIN_PATH . 'templates/checkout/payment-fields-natcash.php';
        
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            ?>
            <div class="wc-haiti-payment-fields">
                <h4><?php _e('Informations de paiement NATCASH', 'wc-haiti-payment-methods'); ?></h4>
                
                <div class="wc-haiti-payment-info">
                    <p><strong><?php _e('Numéro NATCASH:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('natcash_number')); ?></p>
                    <p><strong><?php _e('Nom du compte:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('account_name')); ?></p>
                    <p><strong><?php _e('Montant à payer:', 'wc-haiti-payment-methods'); ?></strong> <?php echo number_format($htg_amount, 2); ?> HTG</p>
                </div>
                
                <div class="wc-haiti-instructions">
                    <p><?php _e('Instructions:', 'wc-haiti-payment-methods'); ?></p>
                    <ol>
                        <li><?php _e('Ouvrez votre application NATCASH', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php printf(__('Envoyez %s HTG au numéro %s', 'wc-haiti-payment-methods'), number_format($htg_amount, 2), esc_html($this->get_option('natcash_number'))); ?></li>
                        <li><?php _e('Prenez une capture d\'écran ou photo de la confirmation', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php _e('Téléchargez votre reçu ci-dessous', 'wc-haiti-payment-methods'); ?></li>
                    </ol>
                </div>
                
                <?php include WC_HAITI_PLUGIN_PATH . 'templates/checkout/receipt-upload.php'; ?>
            </div>
            <?php
        }
    }
    
    /**
     * Validate specific fields
     */
    protected function validate_specific_fields() {
        $errors = array();
        
        // Validate if account information is configured
        if (empty($this->get_option('natcash_number'))) {
            $errors[] = __('Configuration incomplète: Numéro NATCASH manquant.', 'wc-haiti-payment-methods');
        }
        
        if (empty($this->get_option('account_name'))) {
            $errors[] = __('Configuration incomplète: Nom du compte manquant.', 'wc-haiti-payment-methods');
        }
        
        return $errors;
    }
    
    /**
     * Get payment method data
     */
    public function get_payment_data() {
        return array(
            'natcash_number' => $this->get_option('natcash_number'),
            'account_name' => $this->get_option('account_name'),
            'exchange_rate' => $this->usd_to_htg_rate
        );
    }
}
