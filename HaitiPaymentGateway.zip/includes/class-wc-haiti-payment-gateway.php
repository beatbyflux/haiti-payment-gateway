<?php
/**
 * Base payment gateway class for Haiti payment methods
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Payment_Gateway class
 */
abstract class WC_Haiti_Payment_Gateway extends WC_Payment_Gateway {
    
    /**
     * Exchange rate USD to HTG
     */
    protected $usd_to_htg_rate = 134;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->supports = array('products');
        $this->has_fields = true;
        
        // Load settings
        $this->init_form_fields();
        $this->init_settings();
        
        // Get settings
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        
        // Get exchange rate from settings
        $this->usd_to_htg_rate = floatval(get_option('wc_haiti_usd_htg_rate', 134));
        
        // Hooks
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
    }
    
    /**
     * Initialize gateway settings form fields
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Activer/Désactiver', 'wc-haiti-payment-methods'),
                'type' => 'checkbox',
                'label' => __('Activer cette méthode de paiement', 'wc-haiti-payment-methods'),
                'default' => 'no'
            ),
            'title' => array(
                'title' => __('Titre', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Titre affiché aux clients pendant le checkout.', 'wc-haiti-payment-methods'),
                'default' => $this->method_title,
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Description', 'wc-haiti-payment-methods'),
                'type' => 'textarea',
                'description' => __('Description affichée aux clients pendant le checkout.', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
        );
    }
    
    /**
     * Display payment fields
     */
    public function payment_fields() {
        if ($this->description) {
            echo '<p>' . wp_kses_post($this->description) . '</p>';
        }
        
        $this->render_payment_fields();
    }
    
    /**
     * Render specific payment fields - to be implemented by child classes
     */
    abstract protected function render_payment_fields();
    
    /**
     * Validate payment fields
     */
    public function validate_fields() {
        $errors = array();
        
        // Check if receipt file is uploaded
        if (!isset($_FILES['wc_haiti_receipt']) || $_FILES['wc_haiti_receipt']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = __('Veuillez télécharger votre reçu de paiement.', 'wc-haiti-payment-methods');
        } else {
            // Validate file
            $file_validation = WC_Haiti_Receipt_Handler::validate_receipt_file($_FILES['wc_haiti_receipt']);
            if (is_wp_error($file_validation)) {
                $errors[] = $file_validation->get_error_message();
            }
        }
        
        // Validate specific fields
        $specific_errors = $this->validate_specific_fields();
        if (!empty($specific_errors)) {
            $errors = array_merge($errors, $specific_errors);
        }
        
        if (!empty($errors)) {
            foreach ($errors as $error) {
                wc_add_notice($error, 'error');
            }
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate specific fields - to be implemented by child classes
     */
    protected function validate_specific_fields() {
        return array();
    }
    
    /**
     * Process payment
     */
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return array(
                'result' => 'failure',
                'messages' => __('Commande non trouvée.', 'wc-haiti-payment-methods')
            );
        }
        
        try {
            // Upload receipt file
            $receipt_file = WC_Haiti_Receipt_Handler::upload_receipt($_FILES['wc_haiti_receipt'], $order_id);
            
            if (is_wp_error($receipt_file)) {
                throw new Exception($receipt_file->get_error_message());
            }
            
            // Save receipt to database
            $receipt_id = WC_Haiti_Receipt_Handler::save_receipt_data($order_id, $this->id, $receipt_file);
            
            if (!$receipt_id) {
                throw new Exception(__('Erreur lors de la sauvegarde du reçu.', 'wc-haiti-payment-methods'));
            }
            
            // Update order status
            $order->update_status('wc-haiti-pending-verification', __('En attente de vérification du paiement.', 'wc-haiti-payment-methods'));
            
            // Add order note
            $order->add_order_note(sprintf(
                __('Reçu de paiement téléchargé via %s. ID du reçu: %d', 'wc-haiti-payment-methods'),
                $this->method_title,
                $receipt_id
            ));
            
            // Send email notifications
            WC_Haiti_Emails::send_payment_instructions($order, $this->id);
            WC_Haiti_Emails::send_new_receipt_notification($order, $receipt_id);
            
            // Empty cart
            WC()->cart->empty_cart();
            
            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order)
            );
            
        } catch (Exception $e) {
            wc_add_notice($e->getMessage(), 'error');
            return array(
                'result' => 'failure'
            );
        }
    }
    
    /**
     * Receipt page
     */
    public function receipt_page($order_id) {
        $order = wc_get_order($order_id);
        
        if ($order) {
            echo '<div class="wc-haiti-receipt-page">';
            echo '<h3>' . __('Instructions de paiement', 'wc-haiti-payment-methods') . '</h3>';
            echo '<p>' . sprintf(
                __('Votre commande #%s est en cours de traitement. Nous vérifierons votre paiement sous peu.', 'wc-haiti-payment-methods'),
                $order->get_order_number()
            ) . '</p>';
            echo '</div>';
        }
    }
    
    /**
     * Convert USD to HTG
     */
    protected function convert_usd_to_htg($amount) {
        return round($amount * $this->usd_to_htg_rate, 2);
    }
    
    /**
     * Get payment method specific data for display
     */
    abstract public function get_payment_data();
    
    /**
     * Enqueue payment scripts
     */
    public function payment_scripts() {
        // Will be handled by main plugin
    }
}
