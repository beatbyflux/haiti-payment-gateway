<?php
/**
 * Receipt Handler Class
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Receipt_Handler class
 */
class WC_Haiti_Receipt_Handler {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Allowed file types
     */
    private static $allowed_types = array(
        'image/jpeg',
        'image/png',
        'application/pdf'
    );
    
    /**
     * Max file size (5MB)
     */
    private static $max_file_size = 5242880;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('wp_ajax_wc_haiti_approve_receipt', array($this, 'approve_receipt'));
        add_action('wp_ajax_wc_haiti_reject_receipt', array($this, 'reject_receipt'));
        add_action('wp_ajax_wc_haiti_get_receipt_details', array($this, 'get_receipt_details'));
        add_action('wp_ajax_nopriv_wc_haiti_upload_receipt', array($this, 'ajax_upload_receipt'));
        add_action('wp_ajax_wc_haiti_upload_receipt', array($this, 'ajax_upload_receipt'));
    }
    
    /**
     * Validate receipt file
     */
    public static function validate_receipt_file($file) {
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return new WP_Error('upload_error', __('Erreur lors du téléchargement du fichier.', 'wc-haiti-payment-methods'));
        }
        
        // Check file size
        if ($file['size'] > self::$max_file_size) {
            return new WP_Error('file_too_large', __('Le fichier est trop volumineux. Taille maximale autorisée: 5MB.', 'wc-haiti-payment-methods'));
        }
        
        // Check file type
        $file_type = wp_check_filetype($file['name']);
        if (!in_array($file['type'], self::$allowed_types) && !in_array($file_type['type'], self::$allowed_types)) {
            return new WP_Error('invalid_file_type', __('Type de fichier non autorisé. Formats acceptés: JPG, PNG, PDF.', 'wc-haiti-payment-methods'));
        }
        
        // Check if file is actually an image or PDF
        if (in_array($file['type'], array('image/jpeg', 'image/png'))) {
            $image_info = getimagesize($file['tmp_name']);
            if ($image_info === false) {
                return new WP_Error('invalid_image', __('Le fichier n\'est pas une image valide.', 'wc-haiti-payment-methods'));
            }
        } elseif ($file['type'] === 'application/pdf') {
            // Basic PDF validation
            $file_content = file_get_contents($file['tmp_name']);
            if (strpos($file_content, '%PDF') !== 0) {
                return new WP_Error('invalid_pdf', __('Le fichier n\'est pas un PDF valide.', 'wc-haiti-payment-methods'));
            }
        }
        
        return true;
    }
    
    /**
     * Upload receipt file
     */
    public static function upload_receipt($file, $order_id) {
        // Validate file
        $validation = self::validate_receipt_file($file);
        if (is_wp_error($validation)) {
            return $validation;
        }
        
        // Create upload directory if it doesn't exist
        if (!file_exists(WC_HAITI_UPLOADS_DIR)) {
            wp_mkdir_p(WC_HAITI_UPLOADS_DIR);
        }
        
        // Generate secure filename
        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'receipt_' . $order_id . '_' . wp_generate_password(12, false) . '.' . $file_extension;
        $upload_path = WC_HAITI_UPLOADS_DIR . $filename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
            return new WP_Error('upload_failed', __('Échec du téléchargement du fichier.', 'wc-haiti-payment-methods'));
        }
        
        // Set proper file permissions
        chmod($upload_path, 0644);
        
        return $filename;
    }
    
    /**
     * Save receipt data to database
     */
    public static function save_receipt_data($order_id, $payment_method, $receipt_file) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'order_id' => $order_id,
                'payment_method' => $payment_method,
                'receipt_file' => $receipt_file,
                'status' => 'pending',
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            return false;
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Get receipt by ID
     */
    public static function get_receipt($receipt_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $receipt_id
        ));
    }
    
    /**
     * Get receipts by order ID
     */
    public static function get_receipts_by_order($order_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE order_id = %d ORDER BY created_at DESC",
            $order_id
        ));
    }
    
    /**
     * Get all receipts with pagination
     */
    public static function get_all_receipts($status = '', $limit = 20, $offset = 0) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        $where = '';
        $params = array();
        
        if (!empty($status)) {
            $where = 'WHERE status = %s';
            $params[] = $status;
        }
        
        $params[] = $limit;
        $params[] = $offset;
        
        $query = "SELECT * FROM $table_name $where ORDER BY created_at DESC LIMIT %d OFFSET %d";
        
        return $wpdb->get_results($wpdb->prepare($query, $params));
    }
    
    /**
     * Update receipt status
     */
    public static function update_receipt_status($receipt_id, $status, $admin_notes = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        $result = $wpdb->update(
            $table_name,
            array(
                'status' => $status,
                'admin_notes' => $admin_notes,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $receipt_id),
            array('%s', '%s', '%s'),
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Get receipt file URL (secured)
     */
    public static function get_receipt_url($receipt_id) {
        return admin_url('admin-ajax.php?action=wc_haiti_view_receipt&receipt_id=' . $receipt_id . '&nonce=' . wp_create_nonce('wc_haiti_view_receipt'));
    }
    
    /**
     * AJAX handler for approving receipt
     */
    public function approve_receipt() {
        check_ajax_referer('wc_haiti_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('Permissions insuffisantes.', 'wc-haiti-payment-methods'));
        }
        
        $receipt_id = intval($_POST['receipt_id']);
        $admin_notes = sanitize_textarea_field($_POST['admin_notes']);
        
        $receipt = self::get_receipt($receipt_id);
        if (!$receipt) {
            wp_send_json_error(__('Reçu non trouvé.', 'wc-haiti-payment-methods'));
        }
        
        // Update receipt status
        if (self::update_receipt_status($receipt_id, 'verified', $admin_notes)) {
            // Update order status
            $order = wc_get_order($receipt->order_id);
            if ($order) {
                $order->update_status('processing', __('Paiement vérifié et approuvé.', 'wc-haiti-payment-methods'));
                $order->payment_complete();
                
                // Send notification email
                WC_Haiti_Emails::send_receipt_validation_notification($order, 'approved', $admin_notes);
            }
            
            wp_send_json_success(__('Reçu approuvé avec succès.', 'wc-haiti-payment-methods'));
        } else {
            wp_send_json_error(__('Erreur lors de l\'approbation du reçu.', 'wc-haiti-payment-methods'));
        }
    }
    
    /**
     * AJAX handler for rejecting receipt
     */
    public function reject_receipt() {
        check_ajax_referer('wc_haiti_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('Permissions insuffisantes.', 'wc-haiti-payment-methods'));
        }
        
        $receipt_id = intval($_POST['receipt_id']);
        $admin_notes = sanitize_textarea_field($_POST['admin_notes']);
        
        $receipt = self::get_receipt($receipt_id);
        if (!$receipt) {
            wp_send_json_error(__('Reçu non trouvé.', 'wc-haiti-payment-methods'));
        }
        
        // Update receipt status
        if (self::update_receipt_status($receipt_id, 'rejected', $admin_notes)) {
            // Update order status
            $order = wc_get_order($receipt->order_id);
            if ($order) {
                $order->update_status('wc-haiti-payment-rejected', __('Paiement rejeté.', 'wc-haiti-payment-methods'));
                
                // Send notification email
                WC_Haiti_Emails::send_receipt_validation_notification($order, 'rejected', $admin_notes);
            }
            
            wp_send_json_success(__('Reçu rejeté.', 'wc-haiti-payment-methods'));
        } else {
            wp_send_json_error(__('Erreur lors du rejet du reçu.', 'wc-haiti-payment-methods'));
        }
    }
    
    /**
     * AJAX handler for getting receipt details
     */
    public function get_receipt_details() {
        check_ajax_referer('wc_haiti_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('Permissions insuffisantes.', 'wc-haiti-payment-methods'));
        }
        
        $receipt_id = intval($_POST['receipt_id']);
        $receipt = self::get_receipt($receipt_id);
        
        if (!$receipt) {
            wp_send_json_error(__('Reçu non trouvé.', 'wc-haiti-payment-methods'));
        }
        
        $order = wc_get_order($receipt->order_id);
        $receipt_url = self::get_receipt_url($receipt_id);
        
        wp_send_json_success(array(
            'receipt' => $receipt,
            'order' => $order ? $order->get_data() : null,
            'receipt_url' => $receipt_url
        ));
    }
    
    /**
     * AJAX handler for receipt upload
     */
    public function ajax_upload_receipt() {
        check_ajax_referer('wc_haiti_frontend_nonce', 'nonce');
        
        if (!isset($_FILES['receipt']) || !isset($_POST['order_id'])) {
            wp_send_json_error(__('Données manquantes.', 'wc-haiti-payment-methods'));
        }
        
        $order_id = intval($_POST['order_id']);
        $payment_method = sanitize_text_field($_POST['payment_method']);
        
        // Upload file
        $result = self::upload_receipt($_FILES['receipt'], $order_id);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        
        // Save to database
        $receipt_id = self::save_receipt_data($order_id, $payment_method, $result);
        
        if (!$receipt_id) {
            wp_send_json_error(__('Erreur lors de la sauvegarde.', 'wc-haiti-payment-methods'));
        }
        
        wp_send_json_success(__('Reçu téléchargé avec succès.', 'wc-haiti-payment-methods'));
    }
    
    /**
     * Delete receipt file
     */
    public static function delete_receipt_file($filename) {
        $file_path = WC_HAITI_UPLOADS_DIR . $filename;
        if (file_exists($file_path)) {
            return unlink($file_path);
        }
        return false;
    }
    
    /**
     * Get receipt count by status
     */
    public static function get_receipt_count($status = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'haiti_payment_receipts';
        
        if (empty($status)) {
            return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        } else {
            return $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE status = %s",
                $status
            ));
        }
    }
}
