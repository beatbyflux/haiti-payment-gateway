<?php
/**
 * SOGEBANK Payment Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Sogebank_Gateway class
 */
class WC_Haiti_Sogebank_Gateway extends WC_Haiti_Payment_Gateway {
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->id = 'haiti_sogebank';
        $this->icon = '';
        $this->method_title = __('SOGEBANK', 'wc-haiti-payment-methods');
        $this->method_description = __('Paiement via virement bancaire SOGEBANK', 'wc-haiti-payment-methods');
        
        parent::__construct();
    }
    
    /**
     * Initialize gateway settings form fields
     */
    public function init_form_fields() {
        parent::init_form_fields();
        
        $this->form_fields = array_merge($this->form_fields, array(
            'bank_section' => array(
                'title' => __('Informations bancaires SOGEBANK', 'wc-haiti-payment-methods'),
                'type' => 'title',
                'description' => '',
            ),
            'beneficiary_name' => array(
                'title' => __('Nom du bénéficiaire', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Nom complet du titulaire du compte', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'account_number' => array(
                'title' => __('Numéro de compte', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Numéro de compte bancaire SOGEBANK', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'bank_address' => array(
                'title' => __('Adresse de la banque', 'wc-haiti-payment-methods'),
                'type' => 'textarea',
                'description' => __('Adresse complète de la succursale SOGEBANK', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'swift_code' => array(
                'title' => __('Code SWIFT', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Code SWIFT de SOGEBANK', 'wc-haiti-payment-methods'),
                'default' => 'SOGEHTHH',
                'desc_tip' => true,
            ),
        ));
    }
    
    /**
     * Render payment fields
     */
    protected function render_payment_fields() {
        $order_total = WC()->cart->get_total('raw');
        
        $template_path = WC_HAITI_PLUGIN_PATH . 'templates/checkout/payment-fields-bank.php';
        
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            ?>
            <div class="wc-haiti-payment-fields">
                <h4><?php _e('Informations de virement bancaire SOGEBANK', 'wc-haiti-payment-methods'); ?></h4>
                
                <div class="wc-haiti-payment-info">
                    <p><strong><?php _e('Bénéficiaire:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_name')); ?></p>
                    <p><strong><?php _e('Numéro de compte:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('account_number')); ?></p>
                    <p><strong><?php _e('Banque:', 'wc-haiti-payment-methods'); ?></strong> SOGEBANK</p>
                    <p><strong><?php _e('Adresse de la banque:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('bank_address')); ?></p>
                    <p><strong><?php _e('Code SWIFT:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('swift_code')); ?></p>
                    <p><strong><?php _e('Montant à virer:', 'wc-haiti-payment-methods'); ?></strong> $<?php echo number_format($order_total, 2); ?> USD</p>
                </div>
                
                <div class="wc-haiti-instructions">
                    <p><?php _e('Instructions:', 'wc-haiti-payment-methods'); ?></p>
                    <ol>
                        <li><?php _e('Effectuez un virement bancaire avec les informations ci-dessus', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php _e('Conservez votre reçu de transaction', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php _e('Téléchargez une copie de votre reçu ci-dessous', 'wc-haiti-payment-methods'); ?></li>
                    </ol>
                </div>
                
                <?php include WC_HAITI_PLUGIN_PATH . 'templates/checkout/receipt-upload.php'; ?>
            </div>
            <?php
        }
    }
    
    /**
     * Validate specific fields
     */
    protected function validate_specific_fields() {
        $errors = array();
        
        if (empty($this->get_option('beneficiary_name'))) {
            $errors[] = __('Configuration incomplète: Nom du bénéficiaire manquant.', 'wc-haiti-payment-methods');
        }
        
        if (empty($this->get_option('account_number'))) {
            $errors[] = __('Configuration incomplète: Numéro de compte manquant.', 'wc-haiti-payment-methods');
        }
        
        return $errors;
    }
    
    /**
     * Get payment method data
     */
    public function get_payment_data() {
        return array(
            'beneficiary_name' => $this->get_option('beneficiary_name'),
            'account_number' => $this->get_option('account_number'),
            'bank_address' => $this->get_option('bank_address'),
            'swift_code' => $this->get_option('swift_code')
        );
    }
}
