<?php
/**
 * Unitransfert Payment Gateway
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Unitransfert_Gateway class
 */
class WC_Haiti_Unitransfert_Gateway extends WC_Haiti_Payment_Gateway {
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->id = 'haiti_unitransfert';
        $this->icon = '';
        $this->method_title = __('Unitransfert', 'wc-haiti-payment-methods');
        $this->method_description = __('Paiement via service de transfert Unitransfert', 'wc-haiti-payment-methods');
        
        parent::__construct();
    }
    
    /**
     * Initialize gateway settings form fields
     */
    public function init_form_fields() {
        parent::init_form_fields();
        
        $this->form_fields = array_merge($this->form_fields, array(
            'transfer_section' => array(
                'title' => __('Informations du bénéficiaire Unitransfert', 'wc-haiti-payment-methods'),
                'type' => 'title',
                'description' => '',
            ),
            'beneficiary_full_name' => array(
                'title' => __('Nom complet du bénéficiaire', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Nom complet tel qu\'il apparaît sur la pièce d\'identité', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_first_name' => array(
                'title' => __('Prénom', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Prénom du bénéficiaire', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_birth_date' => array(
                'title' => __('Date de naissance', 'wc-haiti-payment-methods'),
                'type' => 'date',
                'description' => __('Date de naissance du bénéficiaire', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_country' => array(
                'title' => __('Pays', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Pays de résidence', 'wc-haiti-payment-methods'),
                'default' => 'Haïti',
                'desc_tip' => true,
            ),
            'beneficiary_city' => array(
                'title' => __('Ville/Département', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Ville ou département de résidence', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_address' => array(
                'title' => __('Adresse complète', 'wc-haiti-payment-methods'),
                'type' => 'textarea',
                'description' => __('Adresse complète du bénéficiaire', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_phone' => array(
                'title' => __('Numéro de téléphone', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Numéro de téléphone du bénéficiaire', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_profession' => array(
                'title' => __('Profession', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Profession du bénéficiaire', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
            'beneficiary_id' => array(
                'title' => __('Pièce d\'identité (optionnel)', 'wc-haiti-payment-methods'),
                'type' => 'text',
                'description' => __('Numéro de la pièce d\'identité (optionnel)', 'wc-haiti-payment-methods'),
                'default' => '',
                'desc_tip' => true,
            ),
        ));
    }
    
    /**
     * Render payment fields
     */
    protected function render_payment_fields() {
        $order_total = WC()->cart->get_total('raw');
        
        $template_path = WC_HAITI_PLUGIN_PATH . 'templates/checkout/payment-fields-transfer.php';
        
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            ?>
            <div class="wc-haiti-payment-fields">
                <h4><?php _e('Informations de transfert Unitransfert', 'wc-haiti-payment-methods'); ?></h4>
                
                <div class="wc-haiti-payment-info">
                    <p><strong><?php _e('Service de transfert:', 'wc-haiti-payment-methods'); ?></strong> Unitransfert</p>
                    <p><strong><?php _e('Bénéficiaire:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_full_name')); ?></p>
                    <p><strong><?php _e('Prénom:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_first_name')); ?></p>
                    <p><strong><?php _e('Date de naissance:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_birth_date')); ?></p>
                    <p><strong><?php _e('Pays:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_country')); ?></p>
                    <p><strong><?php _e('Ville/Département:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_city')); ?></p>
                    <p><strong><?php _e('Adresse:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_address')); ?></p>
                    <p><strong><?php _e('Téléphone:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_phone')); ?></p>
                    <p><strong><?php _e('Profession:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_profession')); ?></p>
                    <?php if ($this->get_option('beneficiary_id')): ?>
                    <p><strong><?php _e('Pièce d\'identité:', 'wc-haiti-payment-methods'); ?></strong> <?php echo esc_html($this->get_option('beneficiary_id')); ?></p>
                    <?php endif; ?>
                    <p><strong><?php _e('Montant à envoyer:', 'wc-haiti-payment-methods'); ?></strong> $<?php echo number_format($order_total, 2); ?> USD</p>
                </div>
                
                <div class="wc-haiti-instructions">
                    <p><?php _e('Instructions:', 'wc-haiti-payment-methods'); ?></p>
                    <ol>
                        <li><?php _e('Rendez-vous dans un bureau Unitransfert près de chez vous', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php _e('Utilisez les informations ci-dessus pour effectuer le transfert', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php _e('Conservez votre reçu de transfert', 'wc-haiti-payment-methods'); ?></li>
                        <li><?php _e('Téléchargez une copie de votre reçu ci-dessous', 'wc-haiti-payment-methods'); ?></li>
                    </ol>
                </div>
                
                <?php include WC_HAITI_PLUGIN_PATH . 'templates/checkout/receipt-upload.php'; ?>
            </div>
            <?php
        }
    }
    
    /**
     * Validate specific fields
     */
    protected function validate_specific_fields() {
        $errors = array();
        
        $required_fields = array(
            'beneficiary_full_name' => __('Nom complet du bénéficiaire', 'wc-haiti-payment-methods'),
            'beneficiary_first_name' => __('Prénom', 'wc-haiti-payment-methods'),
            'beneficiary_birth_date' => __('Date de naissance', 'wc-haiti-payment-methods'),
            'beneficiary_city' => __('Ville/Département', 'wc-haiti-payment-methods'),
            'beneficiary_address' => __('Adresse', 'wc-haiti-payment-methods'),
            'beneficiary_phone' => __('Téléphone', 'wc-haiti-payment-methods'),
            'beneficiary_profession' => __('Profession', 'wc-haiti-payment-methods'),
        );
        
        foreach ($required_fields as $field => $label) {
            if (empty($this->get_option($field))) {
                $errors[] = sprintf(__('Configuration incomplète: %s manquant.', 'wc-haiti-payment-methods'), $label);
            }
        }
        
        return $errors;
    }
    
    /**
     * Get payment method data
     */
    public function get_payment_data() {
        return array(
            'beneficiary_full_name' => $this->get_option('beneficiary_full_name'),
            'beneficiary_first_name' => $this->get_option('beneficiary_first_name'),
            'beneficiary_birth_date' => $this->get_option('beneficiary_birth_date'),
            'beneficiary_country' => $this->get_option('beneficiary_country'),
            'beneficiary_city' => $this->get_option('beneficiary_city'),
            'beneficiary_address' => $this->get_option('beneficiary_address'),
            'beneficiary_phone' => $this->get_option('beneficiary_phone'),
            'beneficiary_profession' => $this->get_option('beneficiary_profession'),
            'beneficiary_id' => $this->get_option('beneficiary_id'),
        );
    }
}
