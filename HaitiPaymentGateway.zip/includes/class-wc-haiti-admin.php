<?php
/**
 * Admin functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Admin class
 */
class WC_Haiti_Admin {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_pages'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'display_order_receipts'));
        add_action('add_meta_boxes', array($this, 'add_order_meta_boxes'));
        add_filter('manage_edit-shop_order_columns', array($this, 'add_order_columns'));
        add_action('manage_shop_order_posts_custom_column', array($this, 'populate_order_columns'), 10, 2);
    }
    
    /**
     * Add admin pages
     */
    public function add_admin_pages() {
        // Main receipts page
        add_submenu_page(
            'woocommerce',
            __('Reçus de Paiement Haïti', 'wc-haiti-payment-methods'),
            __('Reçus Haïti', 'wc-haiti-payment-methods'),
            'manage_woocommerce',
            'wc-haiti-receipts',
            array($this, 'receipts_page')
        );
        
        // Settings page
        add_submenu_page(
            'woocommerce',
            __('Paramètres Paiements Haïti', 'wc-haiti-payment-methods'),
            __('Paramètres Haïti', 'wc-haiti-payment-methods'),
            'manage_woocommerce',
            'wc-haiti-settings',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('wc_haiti_settings', 'wc_haiti_usd_htg_rate');
        register_setting('wc_haiti_settings', 'wc_haiti_auto_approve');
        register_setting('wc_haiti_settings', 'wc_haiti_email_notifications');
    }
    
    /**
     * Receipts page
     */
    public function receipts_page() {
        include WC_HAITI_PLUGIN_PATH . 'admin/admin-receipts.php';
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        include WC_HAITI_PLUGIN_PATH . 'admin/admin-settings.php';
    }
    
    /**
     * Display order receipts in order admin
     */
    public function display_order_receipts($order) {
        $receipts = WC_Haiti_Receipt_Handler::get_receipts_by_order($order->get_id());
        
        if ($receipts) {
            echo '<div class="wc-haiti-order-receipts">';
            echo '<h3>' . __('Reçus de Paiement Haïti', 'wc-haiti-payment-methods') . '</h3>';
            
            foreach ($receipts as $receipt) {
                $status_class = 'wc-haiti-status-' . $receipt->status;
                $status_label = $this->get_status_label($receipt->status);
                
                echo '<div class="wc-haiti-receipt-item ' . esc_attr($status_class) . '">';
                echo '<p><strong>' . __('Méthode:', 'wc-haiti-payment-methods') . '</strong> ' . esc_html($receipt->payment_method) . '</p>';
                echo '<p><strong>' . __('Statut:', 'wc-haiti-payment-methods') . '</strong> ' . esc_html($status_label) . '</p>';
                echo '<p><strong>' . __('Date:', 'wc-haiti-payment-methods') . '</strong> ' . esc_html($receipt->created_at) . '</p>';
                
                if ($receipt->admin_notes) {
                    echo '<p><strong>' . __('Notes:', 'wc-haiti-payment-methods') . '</strong> ' . esc_html($receipt->admin_notes) . '</p>';
                }
                
                echo '<p>';
                echo '<a href="' . esc_url(WC_Haiti_Receipt_Handler::get_receipt_url($receipt->id)) . '" target="_blank" class="button">' . __('Voir le reçu', 'wc-haiti-payment-methods') . '</a> ';
                
                if ($receipt->status === 'pending') {
                    echo '<button type="button" class="button button-primary wc-haiti-approve-receipt" data-receipt-id="' . esc_attr($receipt->id) . '">' . __('Approuver', 'wc-haiti-payment-methods') . '</button> ';
                    echo '<button type="button" class="button wc-haiti-reject-receipt" data-receipt-id="' . esc_attr($receipt->id) . '">' . __('Rejeter', 'wc-haiti-payment-methods') . '</button>';
                }
                
                echo '</p>';
                echo '</div>';
            }
            
            echo '</div>';
        }
    }
    
    /**
     * Add order meta boxes
     */
    public function add_order_meta_boxes() {
        add_meta_box(
            'wc-haiti-receipts',
            __('Reçus de Paiement Haïti', 'wc-haiti-payment-methods'),
            array($this, 'order_receipts_meta_box'),
            'shop_order',
            'normal',
            'default'
        );
    }
    
    /**
     * Order receipts meta box
     */
    public function order_receipts_meta_box($post) {
        $order = wc_get_order($post->ID);
        $this->display_order_receipts($order);
    }
    
    /**
     * Add custom columns to orders list
     */
    public function add_order_columns($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            
            if ($key === 'order_status') {
                $new_columns['wc_haiti_receipt_status'] = __('Reçu Haïti', 'wc-haiti-payment-methods');
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Populate custom order columns
     */
    public function populate_order_columns($column, $post_id) {
        if ($column === 'wc_haiti_receipt_status') {
            $receipts = WC_Haiti_Receipt_Handler::get_receipts_by_order($post_id);
            
            if ($receipts) {
                $latest_receipt = $receipts[0];
                $status_label = $this->get_status_label($latest_receipt->status);
                $status_class = 'wc-haiti-status-' . $latest_receipt->status;
                
                echo '<span class="' . esc_attr($status_class) . '">' . esc_html($status_label) . '</span>';
            } else {
                echo '-';
            }
        }
    }
    
    /**
     * Get status label
     */
    private function get_status_label($status) {
        $labels = array(
            'pending' => __('En attente', 'wc-haiti-payment-methods'),
            'verified' => __('Vérifié', 'wc-haiti-payment-methods'),
            'rejected' => __('Rejeté', 'wc-haiti-payment-methods')
        );
        
        return isset($labels[$status]) ? $labels[$status] : $status;
    }
    
    /**
     * Get dashboard widget data
     */
    public function get_dashboard_data() {
        $data = array(
            'pending_receipts' => WC_Haiti_Receipt_Handler::get_receipt_count('pending'),
            'verified_receipts' => WC_Haiti_Receipt_Handler::get_receipt_count('verified'),
            'rejected_receipts' => WC_Haiti_Receipt_Handler::get_receipt_count('rejected'),
            'total_receipts' => WC_Haiti_Receipt_Handler::get_receipt_count()
        );
        
        return $data;
    }
    
    /**
     * Export receipts to CSV
     */
    public function export_receipts_csv() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('Permissions insuffisantes.', 'wc-haiti-payment-methods'));
        }
        
        $receipts = WC_Haiti_Receipt_Handler::get_all_receipts('', 1000, 0);
        
        $filename = 'haiti-receipts-' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // CSV headers
        fputcsv($output, array(
            __('ID', 'wc-haiti-payment-methods'),
            __('Commande', 'wc-haiti-payment-methods'),
            __('Méthode de paiement', 'wc-haiti-payment-methods'),
            __('Statut', 'wc-haiti-payment-methods'),
            __('Date création', 'wc-haiti-payment-methods'),
            __('Date mise à jour', 'wc-haiti-payment-methods'),
            __('Notes admin', 'wc-haiti-payment-methods')
        ));
        
        // CSV data
        foreach ($receipts as $receipt) {
            fputcsv($output, array(
                $receipt->id,
                $receipt->order_id,
                $receipt->payment_method,
                $this->get_status_label($receipt->status),
                $receipt->created_at,
                $receipt->updated_at,
                $receipt->admin_notes
            ));
        }
        
        fclose($output);
        exit;
    }
}
