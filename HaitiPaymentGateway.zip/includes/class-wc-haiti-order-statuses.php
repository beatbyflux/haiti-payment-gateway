<?php
/**
 * Custom order statuses for Haiti payment methods
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Haiti_Order_Statuses class
 */
class WC_Haiti_Order_Statuses {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Custom statuses
     */
    private static $custom_statuses = array(
        'wc-haiti-pending-payment' => array(
            'label' => 'En attente de paiement',
            'public' => false,
            'exclude_from_search' => false,
            'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => 'En attente de paiement <span class="count">(%s)</span>'
        ),
        'wc-haiti-pending-verification' => array(
            'label' => 'Paiement en cours de vérification',
            'public' => false,
            'exclude_from_search' => false,
            'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => 'En vérification <span class="count">(%s)</span>'
        ),
        'wc-haiti-payment-verified' => array(
            'label' => 'Paiement vérifié',
            'public' => false,
            'exclude_from_search' => false,
            'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => 'Paiement vérifié <span class="count">(%s)</span>'
        ),
        'wc-haiti-payment-rejected' => array(
            'label' => 'Paiement rejeté',
            'public' => false,
            'exclude_from_search' => false,
            'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => 'Paiement rejeté <span class="count">(%s)</span>'
        )
    );
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'register_order_statuses'));
        add_filter('wc_order_statuses', array($this, 'add_order_statuses'));
        add_filter('woocommerce_reports_order_statuses', array($this, 'include_order_statuses_in_reports'));
        add_action('woocommerce_order_status_changed', array($this, 'handle_status_change'), 10, 4);
        
        // Add custom CSS for order statuses
        add_action('admin_head', array($this, 'add_order_status_styles'));
    }
    
    /**
     * Register custom order statuses
     */
    public function register_order_statuses() {
        foreach (self::$custom_statuses as $status => $args) {
            register_post_status($status, array(
                'label' => __($args['label'], 'wc-haiti-payment-methods'),
                'public' => $args['public'],
                'exclude_from_search' => $args['exclude_from_search'],
                'show_in_admin_all_list' => $args['show_in_admin_all_list'],
                'show_in_admin_status_list' => $args['show_in_admin_status_list'],
                'label_count' => _n_noop($args['label_count'], $args['label_count'], 'wc-haiti-payment-methods')
            ));
        }
    }
    
    /**
     * Add custom order statuses to WooCommerce
     */
    public function add_order_statuses($order_statuses) {
        $new_order_statuses = array();
        
        // Add existing statuses
        foreach ($order_statuses as $key => $status) {
            $new_order_statuses[$key] = $status;
            
            // Add our custom statuses after pending
            if ($key === 'wc-pending') {
                foreach (self::$custom_statuses as $status_key => $args) {
                    $new_order_statuses[$status_key] = __($args['label'], 'wc-haiti-payment-methods');
                }
            }
        }
        
        return $new_order_statuses;
    }
    
    /**
     * Include custom statuses in reports
     */
    public function include_order_statuses_in_reports($statuses) {
        $statuses[] = 'haiti-payment-verified';
        return $statuses;
    }
    
    /**
     * Handle order status changes
     */
    public function handle_status_change($order_id, $old_status, $new_status, $order) {
        // Send email notifications for status changes
        if (in_array('wc-' . $new_status, array_keys(self::$custom_statuses))) {
            WC_Haiti_Emails::send_order_status_notification($order, $old_status, 'wc-' . $new_status);
        }
        
        // Handle specific status transitions
        switch ($new_status) {
            case 'haiti-pending-verification':
                $order->add_order_note(__('Commande en attente de vérification du paiement Haïti.', 'wc-haiti-payment-methods'));
                break;
                
            case 'haiti-payment-verified':
                $order->add_order_note(__('Paiement Haïti vérifié et approuvé.', 'wc-haiti-payment-methods'));
                // Reduce stock levels if not already done
                if (!$order->get_data_store()->get_stock_reduced($order_id)) {
                    wc_reduce_stock_levels($order_id);
                }
                break;
                
            case 'haiti-payment-rejected':
                $order->add_order_note(__('Paiement Haïti rejeté.', 'wc-haiti-payment-methods'));
                break;
        }
    }
    
    /**
     * Add custom CSS for order statuses
     */
    public function add_order_status_styles() {
        ?>
        <style>
        .order-status.status-haiti-pending-payment {
            background: #ffb900;
            color: #ffffff;
        }
        .order-status.status-haiti-pending-verification {
            background: #0073aa;
            color: #ffffff;
        }
        .order-status.status-haiti-payment-verified {
            background: #46b450;
            color: #ffffff;
        }
        .order-status.status-haiti-payment-rejected {
            background: #dc3232;
            color: #ffffff;
        }
        .wc-haiti-status-pending {
            color: #ffb900;
            font-weight: bold;
        }
        .wc-haiti-status-verified {
            color: #46b450;
            font-weight: bold;
        }
        .wc-haiti-status-rejected {
            color: #dc3232;
            font-weight: bold;
        }
        </style>
        <?php
    }
    
    /**
     * Get custom status by key
     */
    public static function get_status($status_key) {
        return isset(self::$custom_statuses[$status_key]) ? self::$custom_statuses[$status_key] : null;
    }
    
    /**
     * Check if status is custom Haiti status
     */
    public static function is_haiti_status($status) {
        return array_key_exists($status, self::$custom_statuses);
    }
    
    /**
     * Get all custom statuses
     */
    public static function get_all_statuses() {
        return self::$custom_statuses;
    }
}
