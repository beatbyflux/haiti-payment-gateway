<?php
/**
 * Admin settings page
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['submit']) && wp_verify_nonce($_POST['_wpnonce'], 'wc_haiti_settings')) {
    update_option('wc_haiti_usd_htg_rate', floatval($_POST['wc_haiti_usd_htg_rate']));
    update_option('wc_haiti_auto_approve', isset($_POST['wc_haiti_auto_approve']) ? 'yes' : 'no');
    update_option('wc_haiti_email_notifications', isset($_POST['wc_haiti_email_notifications']) ? 'yes' : 'no');
    
    echo '<div class="notice notice-success"><p>' . __('Paramètres sauvegardés.', 'wc-haiti-payment-methods') . '</p></div>';
}

// Get current settings
$usd_htg_rate = get_option('wc_haiti_usd_htg_rate', 134);
$auto_approve = get_option('wc_haiti_auto_approve', 'no');
$email_notifications = get_option('wc_haiti_email_notifications', 'yes');
?>

<div class="wrap">
    <h1><?php _e('Paramètres des Paiements Haïti', 'wc-haiti-payment-methods'); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('wc_haiti_settings'); ?>
        
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="wc_haiti_usd_htg_rate"><?php _e('Taux de change USD/HTG', 'wc-haiti-payment-methods'); ?></label>
                    </th>
                    <td>
                        <input type="number" step="0.01" id="wc_haiti_usd_htg_rate" name="wc_haiti_usd_htg_rate" value="<?php echo esc_attr($usd_htg_rate); ?>" class="regular-text" />
                        <p class="description"><?php _e('Taux de change utilisé pour convertir USD en HTG pour NATCASH.', 'wc-haiti-payment-methods'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="wc_haiti_auto_approve"><?php _e('Approbation automatique', 'wc-haiti-payment-methods'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="wc_haiti_auto_approve" name="wc_haiti_auto_approve" value="yes" <?php checked($auto_approve, 'yes'); ?> />
                            <?php _e('Approuver automatiquement tous les reçus de paiement', 'wc-haiti-payment-methods'); ?>
                        </label>
                        <p class="description"><?php _e('Si activé, tous les reçus seront automatiquement approuvés sans validation manuelle.', 'wc-haiti-payment-methods'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="wc_haiti_email_notifications"><?php _e('Notifications par email', 'wc-haiti-payment-methods'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="wc_haiti_email_notifications" name="wc_haiti_email_notifications" value="yes" <?php checked($email_notifications, 'yes'); ?> />
                            <?php _e('Envoyer des notifications par email pour les changements de statut', 'wc-haiti-payment-methods'); ?>
                        </label>
                        <p class="description"><?php _e('Si activé, des emails seront envoyés aux clients et administrateurs lors des changements de statut.', 'wc-haiti-payment-methods'); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <h2><?php _e('Configuration des méthodes de paiement', 'wc-haiti-payment-methods'); ?></h2>
        <p><?php _e('Pour configurer les méthodes de paiement individuelles, rendez-vous dans:', 'wc-haiti-payment-methods'); ?></p>
        <p>
            <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout'); ?>" class="button">
                <?php _e('WooCommerce > Réglages > Paiements', 'wc-haiti-payment-methods'); ?>
            </a>
        </p>
        
        <h2><?php _e('Statistiques', 'wc-haiti-payment-methods'); ?></h2>
        <?php
        $admin = WC_Haiti_Admin::get_instance();
        $stats = $admin->get_dashboard_data();
        ?>
        <table class="widefat">
            <tbody>
                <tr>
                    <td><?php _e('Reçus en attente', 'wc-haiti-payment-methods'); ?></td>
                    <td><strong><?php echo esc_html($stats['pending_receipts']); ?></strong></td>
                </tr>
                <tr>
                    <td><?php _e('Reçus vérifiés', 'wc-haiti-payment-methods'); ?></td>
                    <td><strong><?php echo esc_html($stats['verified_receipts']); ?></strong></td>
                </tr>
                <tr>
                    <td><?php _e('Reçus rejetés', 'wc-haiti-payment-methods'); ?></td>
                    <td><strong><?php echo esc_html($stats['rejected_receipts']); ?></strong></td>
                </tr>
                <tr>
                    <td><?php _e('Total des reçus', 'wc-haiti-payment-methods'); ?></td>
                    <td><strong><?php echo esc_html($stats['total_receipts']); ?></strong></td>
                </tr>
            </tbody>
        </table>
        
        <h2><?php _e('Maintenance', 'wc-haiti-payment-methods'); ?></h2>
        <p><?php _e('Outils de maintenance et nettoyage:', 'wc-haiti-payment-methods'); ?></p>
        <p>
            <button type="button" class="button" id="wc-haiti-cleanup-files">
                <?php _e('Nettoyer les fichiers orphelins', 'wc-haiti-payment-methods'); ?>
            </button>
            <span class="description"><?php _e('Supprime les fichiers de reçus qui ne sont plus liés à des commandes.', 'wc-haiti-payment-methods'); ?></span>
        </p>
        
        <?php submit_button(__('Sauvegarder les paramètres', 'wc-haiti-payment-methods')); ?>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    $('#wc-haiti-cleanup-files').on('click', function() {
        if (confirm('<?php _e('Êtes-vous sûr de vouloir nettoyer les fichiers orphelins ?', 'wc-haiti-payment-methods'); ?>')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wc_haiti_cleanup_files',
                    nonce: '<?php echo wp_create_nonce('wc_haiti_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        alert('<?php _e('Nettoyage terminé.', 'wc-haiti-payment-methods'); ?>');
                    } else {
                        alert('<?php _e('Erreur lors du nettoyage.', 'wc-haiti-payment-methods'); ?>');
                    }
                }
            });
        }
    });
});
</script>
