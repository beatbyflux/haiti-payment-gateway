<?php
/**
 * Admin receipts management page
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle actions
if (isset($_GET['action']) && isset($_GET['receipt_id'])) {
    $receipt_id = intval($_GET['receipt_id']);
    $action = sanitize_text_field($_GET['action']);
    
    if (!wp_verify_nonce($_GET['nonce'], 'wc_haiti_receipt_action')) {
        wp_die(__('Vérification de sécurité échouée.', 'wc-haiti-payment-methods'));
    }
    
    switch ($action) {
        case 'view':
            $receipt = WC_Haiti_Receipt_Handler::get_receipt($receipt_id);
            if ($receipt) {
                $file_path = WC_HAITI_UPLOADS_DIR . $receipt->receipt_file;
                if (file_exists($file_path)) {
                    $file_type = wp_check_filetype($receipt->receipt_file);
                    
                    header('Content-Type: ' . $file_type['type']);
                    header('Content-Disposition: inline; filename="' . basename($receipt->receipt_file) . '"');
                    readfile($file_path);
                    exit;
                }
            }
            break;
    }
}

// Get current tab
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'pending';

// Get receipts based on tab
$receipts = WC_Haiti_Receipt_Handler::get_all_receipts($current_tab === 'all' ? '' : $current_tab, 50, 0);

// Get counts for tabs
$pending_count = WC_Haiti_Receipt_Handler::get_receipt_count('pending');
$verified_count = WC_Haiti_Receipt_Handler::get_receipt_count('verified');
$rejected_count = WC_Haiti_Receipt_Handler::get_receipt_count('rejected');
$total_count = WC_Haiti_Receipt_Handler::get_receipt_count();
?>

<div class="wrap">
    <h1><?php _e('Gestion des Reçus de Paiement Haïti', 'wc-haiti-payment-methods'); ?></h1>
    
    <!-- Tabs -->
    <nav class="nav-tab-wrapper">
        <a href="<?php echo admin_url('admin.php?page=wc-haiti-receipts&tab=pending'); ?>" class="nav-tab <?php echo $current_tab === 'pending' ? 'nav-tab-active' : ''; ?>">
            <?php printf(__('En attente (%d)', 'wc-haiti-payment-methods'), $pending_count); ?>
        </a>
        <a href="<?php echo admin_url('admin.php?page=wc-haiti-receipts&tab=verified'); ?>" class="nav-tab <?php echo $current_tab === 'verified' ? 'nav-tab-active' : ''; ?>">
            <?php printf(__('Vérifiés (%d)', 'wc-haiti-payment-methods'), $verified_count); ?>
        </a>
        <a href="<?php echo admin_url('admin.php?page=wc-haiti-receipts&tab=rejected'); ?>" class="nav-tab <?php echo $current_tab === 'rejected' ? 'nav-tab-active' : ''; ?>">
            <?php printf(__('Rejetés (%d)', 'wc-haiti-payment-methods'), $rejected_count); ?>
        </a>
        <a href="<?php echo admin_url('admin.php?page=wc-haiti-receipts&tab=all'); ?>" class="nav-tab <?php echo $current_tab === 'all' ? 'nav-tab-active' : ''; ?>">
            <?php printf(__('Tous (%d)', 'wc-haiti-payment-methods'), $total_count); ?>
        </a>
    </nav>
    
    <!-- Actions bar -->
    <div class="wc-haiti-actions-bar" style="margin: 20px 0;">
        <a href="<?php echo admin_url('admin.php?page=wc-haiti-receipts&action=export_csv&nonce=' . wp_create_nonce('wc_haiti_export')); ?>" class="button">
            <?php _e('Exporter CSV', 'wc-haiti-payment-methods'); ?>
        </a>
        <span class="description"><?php _e('Exporter tous les reçus au format CSV', 'wc-haiti-payment-methods'); ?></span>
    </div>
    
    <!-- Receipts table -->
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th scope="col"><?php _e('ID', 'wc-haiti-payment-methods'); ?></th>
                <th scope="col"><?php _e('Commande', 'wc-haiti-payment-methods'); ?></th>
                <th scope="col"><?php _e('Client', 'wc-haiti-payment-methods'); ?></th>
                <th scope="col"><?php _e('Méthode de paiement', 'wc-haiti-payment-methods'); ?></th>
                <th scope="col"><?php _e('Statut', 'wc-haiti-payment-methods'); ?></th>
                <th scope="col"><?php _e('Date', 'wc-haiti-payment-methods'); ?></th>
                <th scope="col"><?php _e('Actions', 'wc-haiti-payment-methods'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ($receipts): ?>
                <?php foreach ($receipts as $receipt): ?>
                    <?php
                    $order = wc_get_order($receipt->order_id);
                    $status_class = 'wc-haiti-status-' . $receipt->status;
                    $status_labels = array(
                        'pending' => __('En attente', 'wc-haiti-payment-methods'),
                        'verified' => __('Vérifié', 'wc-haiti-payment-methods'),
                        'rejected' => __('Rejeté', 'wc-haiti-payment-methods')
                    );
                    $status_label = isset($status_labels[$receipt->status]) ? $status_labels[$receipt->status] : $receipt->status;
                    ?>
                    <tr>
                        <td><?php echo esc_html($receipt->id); ?></td>
                        <td>
                            <?php if ($order): ?>
                                <a href="<?php echo admin_url('post.php?post=' . $receipt->order_id . '&action=edit'); ?>">
                                    #<?php echo esc_html($order->get_order_number()); ?>
                                </a>
                                <br>
                                <span class="description"><?php echo esc_html($order->get_formatted_order_total()); ?></span>
                            <?php else: ?>
                                #<?php echo esc_html($receipt->order_id); ?> <em>(<?php _e('Supprimée', 'wc-haiti-payment-methods'); ?>)</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($order): ?>
                                <?php echo esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()); ?>
                                <br>
                                <span class="description"><?php echo esc_html($order->get_billing_email()); ?></span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($receipt->payment_method); ?></td>
                        <td>
                            <span class="<?php echo esc_attr($status_class); ?>">
                                <?php echo esc_html($status_label); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($receipt->created_at))); ?>
                            <?php if ($receipt->updated_at && $receipt->updated_at !== $receipt->created_at): ?>
                                <br>
                                <span class="description"><?php printf(__('Mis à jour: %s', 'wc-haiti-payment-methods'), date_i18n(get_option('date_format'), strtotime($receipt->updated_at))); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="button" class="button wc-haiti-view-receipt" data-receipt-id="<?php echo esc_attr($receipt->id); ?>">
                                <?php _e('Voir', 'wc-haiti-payment-methods'); ?>
                            </button>
                            
                            <?php if ($receipt->status === 'pending'): ?>
                                <button type="button" class="button button-primary wc-haiti-approve-receipt" data-receipt-id="<?php echo esc_attr($receipt->id); ?>">
                                    <?php _e('Approuver', 'wc-haiti-payment-methods'); ?>
                                </button>
                                <button type="button" class="button wc-haiti-reject-receipt" data-receipt-id="<?php echo esc_attr($receipt->id); ?>">
                                    <?php _e('Rejeter', 'wc-haiti-payment-methods'); ?>
                                </button>
                            <?php endif; ?>
                            
                            <?php if ($receipt->admin_notes): ?>
                                <br>
                                <span class="description"><?php printf(__('Notes: %s', 'wc-haiti-payment-methods'), esc_html($receipt->admin_notes)); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">
                        <p><?php _e('Aucun reçu trouvé.', 'wc-haiti-payment-methods'); ?></p>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Receipt Modal -->
<div id="wc-haiti-receipt-modal" class="wc-haiti-modal" style="display: none;">
    <div class="wc-haiti-modal-content">
        <div class="wc-haiti-modal-header">
            <h3><?php _e('Détails du reçu', 'wc-haiti-payment-methods'); ?></h3>
            <button type="button" class="wc-haiti-modal-close">&times;</button>
        </div>
        <div class="wc-haiti-modal-body">
            <div id="wc-haiti-receipt-details"></div>
            <iframe id="wc-haiti-receipt-preview" style="width: 100%; height: 400px; border: 1px solid #ddd;"></iframe>
        </div>
        <div class="wc-haiti-modal-footer">
            <button type="button" class="button wc-haiti-modal-close"><?php _e('Fermer', 'wc-haiti-payment-methods'); ?></button>
        </div>
    </div>
</div>

<!-- Approval Modal -->
<div id="wc-haiti-approval-modal" class="wc-haiti-modal" style="display: none;">
    <div class="wc-haiti-modal-content">
        <div class="wc-haiti-modal-header">
            <h3 id="wc-haiti-approval-title"><?php _e('Approuver le reçu', 'wc-haiti-payment-methods'); ?></h3>
            <button type="button" class="wc-haiti-modal-close">&times;</button>
        </div>
        <div class="wc-haiti-modal-body">
            <form id="wc-haiti-approval-form">
                <p>
                    <label for="wc-haiti-admin-notes"><?php _e('Notes administratives (optionnel):', 'wc-haiti-payment-methods'); ?></label>
                    <textarea id="wc-haiti-admin-notes" name="admin_notes" rows="4" style="width: 100%;"></textarea>
                </p>
                <input type="hidden" id="wc-haiti-receipt-id" name="receipt_id" value="">
                <input type="hidden" id="wc-haiti-action-type" name="action_type" value="">
            </form>
        </div>
        <div class="wc-haiti-modal-footer">
            <button type="button" class="button button-primary" id="wc-haiti-confirm-action"><?php _e('Confirmer', 'wc-haiti-payment-methods'); ?></button>
            <button type="button" class="button wc-haiti-modal-close"><?php _e('Annuler', 'wc-haiti-payment-methods'); ?></button>
        </div>
    </div>
</div>
